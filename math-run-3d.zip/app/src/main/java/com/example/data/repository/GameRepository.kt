package com.example.data.repository

import com.example.data.db.MathRunDao
import com.example.data.model.PlayerProfileEntity
import com.example.data.model.RunRecordEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import org.json.JSONArray

class GameRepository(private val dao: MathRunDao) {

    val playerProfile: Flow<PlayerProfileEntity?> = dao.getPlayerProfile()
    val topRecords: Flow<List<RunRecordEntity>> = dao.getTopRunRecords()
    val recentRecords: Flow<List<RunRecordEntity>> = dao.getRecentRunRecords()
    val highestScore: Flow<Int?> = dao.getHighestScore()
    val highestDistance: Flow<Int?> = dao.getHighestDistance()
    val highestCombo: Flow<Int?> = dao.getHighestCombo()
    val totalCoinsEarned: Flow<Int?> = dao.getTotalCoinsEarned()
    val totalCorrectAnswers: Flow<Int?> = dao.getTotalCorrectAnswers()
    val totalRunsCount: Flow<Int> = dao.getTotalRunsCount()

    suspend fun ensureProfile(): PlayerProfileEntity {
        val current = dao.getPlayerProfile().firstOrNull()
        if (current != null) return current
        val initial = PlayerProfileEntity()
        dao.insertOrUpdateProfile(initial)
        return initial
    }

    suspend fun saveRunResult(
        score: Int,
        coinsEarned: Int,
        correctCount: Int,
        wrongCount: Int,
        bestCombo: Int,
        distanceMeters: Int,
        mode: String,
        world: String
    ): Long {
        val profile = ensureProfile()
        val xpGained = score / 5 + correctCount * 15 + coinsEarned * 2
        val newXp = profile.xp + xpGained
        val newLevel = (newXp / 500) + 1
        val newTotalCoins = profile.totalCoins + coinsEarned

        dao.insertOrUpdateProfile(
            profile.copy(
                totalCoins = newTotalCoins,
                xp = newXp,
                level = newLevel
            )
        )

        return dao.insertRunRecord(
            RunRecordEntity(
                score = score,
                coins = coinsEarned,
                correctCount = correctCount,
                wrongCount = wrongCount,
                bestCombo = bestCombo,
                distanceMeters = distanceMeters,
                mode = mode,
                world = world
            )
        )
    }

    suspend fun updateSkin(skinId: String) {
        val profile = ensureProfile()
        dao.insertOrUpdateProfile(profile.copy(currentSkinId = skinId))
    }

    suspend fun unlockSkin(skinId: String, cost: Int): Boolean {
        val profile = ensureProfile()
        if (profile.totalCoins < cost) return false

        val currentUnlocked = parseUnlockedSkins(profile.unlockedSkinIdsJson).toMutableSet()
        currentUnlocked.add(skinId)
        val jsonArray = JSONArray(currentUnlocked.toList()).toString()

        dao.insertOrUpdateProfile(
            profile.copy(
                totalCoins = profile.totalCoins - cost,
                unlockedSkinIdsJson = jsonArray,
                currentSkinId = skinId
            )
        )
        return true
    }

    suspend fun upgradePowerUp(type: String, cost: Int): Boolean {
        val profile = ensureProfile()
        if (profile.totalCoins < cost) return false

        val updated = when (type) {
            "MAGNET" -> profile.copy(totalCoins = profile.totalCoins - cost, magnetLvl = (profile.magnetLvl + 1).coerceAtMost(5))
            "SHIELD" -> profile.copy(totalCoins = profile.totalCoins - cost, shieldLvl = (profile.shieldLvl + 1).coerceAtMost(5))
            "EXTRA_TIME" -> profile.copy(totalCoins = profile.totalCoins - cost, extraTimeLvl = (profile.extraTimeLvl + 1).coerceAtMost(5))
            "SPEED_BOOST" -> profile.copy(totalCoins = profile.totalCoins - cost, speedBoostLvl = (profile.speedBoostLvl + 1).coerceAtMost(5))
            else -> profile
        }
        dao.insertOrUpdateProfile(updated)
        return true
    }

    suspend fun updateSettings(
        soundEnabled: Boolean,
        musicEnabled: Boolean,
        hapticsEnabled: Boolean,
        swipeSensitivity: Float,
        graphicsQuality: String
    ) {
        val profile = ensureProfile()
        dao.insertOrUpdateProfile(
            profile.copy(
                soundEnabled = soundEnabled,
                musicEnabled = musicEnabled,
                hapticsEnabled = hapticsEnabled,
                swipeSensitivity = swipeSensitivity,
                graphicsQuality = graphicsQuality
            )
        )
    }

    suspend fun markTutorialCompleted() {
        val profile = ensureProfile()
        dao.insertOrUpdateProfile(profile.copy(completedTutorial = true))
    }

    suspend fun resetAllData() {
        val defaultProfile = PlayerProfileEntity()
        dao.insertOrUpdateProfile(defaultProfile)
    }

    companion object {
        fun parseUnlockedSkins(json: String): Set<String> {
            val list = mutableSetOf("classic")
            try {
                val array = JSONArray(json)
                for (i in 0 until array.length()) {
                    list.add(array.getString(i))
                }
            } catch (_: Exception) {}
            return list
        }
    }
}
