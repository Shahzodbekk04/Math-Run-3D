package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val totalCoins: Int = 150,
    val xp: Int = 0,
    val level: Int = 1,
    val currentSkinId: String = "classic",
    val unlockedSkinIdsJson: String = "[\"classic\"]",
    val magnetLvl: Int = 1,
    val shieldLvl: Int = 1,
    val extraTimeLvl: Int = 1,
    val speedBoostLvl: Int = 1,
    val soundEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val swipeSensitivity: Float = 1.0f,
    val graphicsQuality: String = "HIGH", // LOW, MEDIUM, HIGH
    val completedTutorial: Boolean = false
)

@Entity(tableName = "run_records")
data class RunRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val score: Int,
    val coins: Int,
    val correctCount: Int,
    val wrongCount: Int,
    val bestCombo: Int,
    val distanceMeters: Int,
    val mode: String, // ADDITION, SUBTRACTION, MULTIPLICATION, DIVISION
    val world: String,
    val timestamp: Long = System.currentTimeMillis()
)
