package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.PlayerProfileEntity
import com.example.data.model.RunRecordEntity

@Database(
    entities = [PlayerProfileEntity::class, RunRecordEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MathRunDatabase : RoomDatabase() {
    abstract fun mathRunDao(): MathRunDao

    companion object {
        @Volatile
        private var INSTANCE: MathRunDatabase? = null

        fun getDatabase(context: Context): MathRunDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MathRunDatabase::class.java,
                    "math_run_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
