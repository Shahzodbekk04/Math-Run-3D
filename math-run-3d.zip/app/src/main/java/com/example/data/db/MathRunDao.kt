package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.PlayerProfileEntity
import com.example.data.model.RunRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MathRunDao {
    @Query("SELECT * FROM player_profile WHERE id = 1 LIMIT 1")
    fun getPlayerProfile(): Flow<PlayerProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: PlayerProfileEntity)

    @Update
    suspend fun updateProfile(profile: PlayerProfileEntity)

    @Query("SELECT * FROM run_records ORDER BY score DESC LIMIT 50")
    fun getTopRunRecords(): Flow<List<RunRecordEntity>>

    @Query("SELECT * FROM run_records ORDER BY timestamp DESC LIMIT 20")
    fun getRecentRunRecords(): Flow<List<RunRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRunRecord(record: RunRecordEntity): Long

    @Query("SELECT MAX(score) FROM run_records")
    fun getHighestScore(): Flow<Int?>

    @Query("SELECT MAX(distanceMeters) FROM run_records")
    fun getHighestDistance(): Flow<Int?>

    @Query("SELECT MAX(bestCombo) FROM run_records")
    fun getHighestCombo(): Flow<Int?>

    @Query("SELECT SUM(coins) FROM run_records")
    fun getTotalCoinsEarned(): Flow<Int?>

    @Query("SELECT SUM(correctCount) FROM run_records")
    fun getTotalCorrectAnswers(): Flow<Int?>

    @Query("SELECT COUNT(*) FROM run_records")
    fun getTotalRunsCount(): Flow<Int>
}
