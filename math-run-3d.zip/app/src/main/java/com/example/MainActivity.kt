package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.game.engine.AppScreen
import com.example.game.engine.GameViewModel
import com.example.ui.screens.GameOverScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.SkinsShopScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.UpgradesScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = com.example.ui.theme.Slate950
                ) {
                    MathRun3DApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.audioSynthesizer.stopBackgroundMusic()
    }

    override fun onResume() {
        super.onResume()
        val profile = viewModel.playerProfile.value
        if (profile?.musicEnabled == true) {
            viewModel.audioSynthesizer.startBackgroundMusic()
        }
    }
}

@Composable
fun MathRun3DApp(viewModel: GameViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val profile by viewModel.playerProfile.collectAsState()
    val topRecords by viewModel.topRecords.collectAsState()
    val totalRuns by viewModel.totalRunsCount.collectAsState()

    Crossfade(targetState = uiState.currentScreen, label = "screen_crossfade") { screen ->
        when (screen) {
            AppScreen.MENU -> {
                MainMenuScreen(
                    uiState = uiState,
                    profile = profile,
                    onStartGame = { mode -> viewModel.startRun(mode) },
                    onNavigate = { dest -> viewModel.navigateTo(dest) },
                    onSelectWorld = { world -> viewModel.selectWorld(world) }
                )
            }
            AppScreen.GAME -> {
                GameScreen(
                    viewModel = viewModel,
                    uiState = uiState,
                    onNavigate = { dest -> viewModel.navigateTo(dest) }
                )
            }
            AppScreen.GAME_OVER -> {
                GameOverScreen(
                    uiState = uiState,
                    profile = profile,
                    onRestart = { viewModel.startRun(uiState.selectedMode) },
                    onNavigate = { dest -> viewModel.navigateTo(dest) }
                )
            }
            AppScreen.SKINS -> {
                SkinsShopScreen(
                    uiState = uiState,
                    profile = profile,
                    onBuySkin = { skin -> viewModel.buySkin(skin) },
                    onEquipSkin = { skin -> viewModel.equipSkin(skin) },
                    onNavigate = { dest -> viewModel.navigateTo(dest) }
                )
            }
            AppScreen.UPGRADES -> {
                UpgradesScreen(
                    profile = profile,
                    onUpgrade = { id, cost -> viewModel.upgradePowerUp(id, cost) },
                    onNavigate = { dest -> viewModel.navigateTo(dest) }
                )
            }
            AppScreen.LEADERBOARD -> {
                LeaderboardScreen(
                    topRecords = topRecords,
                    totalRuns = totalRuns,
                    onNavigate = { dest -> viewModel.navigateTo(dest) }
                )
            }
            AppScreen.SETTINGS -> {
                SettingsScreen(
                    profile = profile,
                    onSaveSettings = { sound, music, haptics, sens, gfx ->
                        viewModel.updateSettings(sound, music, haptics, sens, gfx)
                    },
                    onReplayTutorial = {
                        viewModel.navigateTo(AppScreen.GAME)
                    },
                    onNavigate = { dest -> viewModel.navigateTo(dest) }
                )
            }
        }
    }
}
