package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlayerProfileEntity
import com.example.game.engine.AppScreen
import com.example.ui.theme.BlueElectric
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@Composable
fun SettingsScreen(
    profile: PlayerProfileEntity?,
    onSaveSettings: (sound: Boolean, music: Boolean, haptics: Boolean, sensitivity: Float, graphics: String) -> Unit,
    onReplayTutorial: () -> Unit,
    onNavigate: (AppScreen) -> Unit
) {
    var soundEnabled by remember(profile) { mutableStateOf(profile?.soundEnabled ?: true) }
    var musicEnabled by remember(profile) { mutableStateOf(profile?.musicEnabled ?: true) }
    var hapticsEnabled by remember(profile) { mutableStateOf(profile?.hapticsEnabled ?: true) }
    var swipeSensitivity by remember(profile) { mutableFloatStateOf(profile?.swipeSensitivity ?: 1.0f) }
    var graphicsQuality by remember(profile) { mutableStateOf(profile?.graphicsQuality ?: "HIGH") }

    fun commit() {
        onSaveSettings(soundEnabled, musicEnabled, hapticsEnabled, swipeSensitivity, graphicsQuality)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Slate900,
                        Slate800,
                        Slate950
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // TOP BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onNavigate(AppScreen.MENU) },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Slate900.copy(alpha = 0.8f), CircleShape)
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)), CircleShape)
                        .testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Ortga",
                        tint = Color.White
                    )
                }

                Text(
                    text = "SOZLAMALAR",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                Box(modifier = Modifier.size(40.dp))
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp)
            ) {
                // AUDIO SECTION
                item {
                    Text(
                        text = "OVOZ VA EFFEKTLAR",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate400,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate900.copy(alpha = 0.8f)),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            SettingToggleRow(
                                icon = Icons.Default.VolumeUp,
                                label = "Ovoz effektlari",
                                isChecked = soundEnabled,
                                onCheckedChange = {
                                    soundEnabled = it
                                    commit()
                                }
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            SettingToggleRow(
                                icon = Icons.Default.MusicNote,
                                label = "Fon musiqasi",
                                isChecked = musicEnabled,
                                onCheckedChange = {
                                    musicEnabled = it
                                    commit()
                                }
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            SettingToggleRow(
                                icon = Icons.Default.Vibration,
                                label = "Tebranish (Haptics)",
                                isChecked = hapticsEnabled,
                                onCheckedChange = {
                                    hapticsEnabled = it
                                    commit()
                                }
                            )
                        }
                    }
                }

                // CONTROLS SECTION
                item {
                    Text(
                        text = "BOSHQARUV VA SEZGIRLIK",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate400,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate900.copy(alpha = 0.8f)),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.TouchApp, contentDescription = null, tint = BlueElectric)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "Swipe sezgirligi",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Text(
                                    text = "${String.format("%.1f", swipeSensitivity)}x",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueElectric
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Slider(
                                value = swipeSensitivity,
                                onValueChange = {
                                    swipeSensitivity = it
                                    commit()
                                },
                                valueRange = 0.5f..2.0f,
                                colors = SliderDefaults.colors(
                                    thumbColor = BlueElectric,
                                    activeTrackColor = BlueElectric,
                                    inactiveTrackColor = Slate800
                                )
                            )
                        }
                    }
                }

                // GRAPHICS QUALITY SECTION
                item {
                    Text(
                        text = "GRAFIKA VA UNUMLIK",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate400,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate900.copy(alpha = 0.8f)),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Grafik sifat (Batareya va FPS optimallashtirish):",
                                fontSize = 13.sp,
                                color = Slate300
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                QualityOption(
                                    label = "Past",
                                    isSelected = graphicsQuality == "LOW",
                                    onClick = { graphicsQuality = "LOW"; commit() },
                                    modifier = Modifier.weight(1f)
                                )
                                QualityOption(
                                    label = "O‘rta",
                                    isSelected = graphicsQuality == "MEDIUM",
                                    onClick = { graphicsQuality = "MEDIUM"; commit() },
                                    modifier = Modifier.weight(1f)
                                )
                                QualityOption(
                                    label = "Yuqori",
                                    isSelected = graphicsQuality == "HIGH",
                                    onClick = { graphicsQuality = "HIGH"; commit() },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // TUTORIAL & RESET
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onReplayTutorial,
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = null, tint = BlueElectric)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("QOIDALAR / TUTORIALNI KO‘RSATISH", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingToggleRow(
    icon: ImageVector,
    label: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = BlueElectric, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = label,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        }
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = EmeraldNeon,
                uncheckedThumbColor = Slate400,
                uncheckedTrackColor = Slate800
            )
        )
    }
}

@Composable
fun QualityOption(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (isSelected) Color(0xFF2563EB) else Slate950,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(
            1.dp,
            if (isSelected) BlueElectric else Color.White.copy(alpha = 0.1f)
        ),
        modifier = modifier
            .height(40.dp),
        onClick = onClick
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

