package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RunRecordEntity
import com.example.game.engine.AppScreen
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.BlueElectric
import com.example.ui.theme.OrangeCombo
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LeaderboardScreen(
    topRecords: List<RunRecordEntity>,
    totalRuns: Int,
    onNavigate: (AppScreen) -> Unit
) {
    val bestScore = topRecords.maxOfOrNull { it.score } ?: 0
    val bestDistance = topRecords.maxOfOrNull { it.distanceMeters } ?: 0
    val bestCombo = topRecords.maxOfOrNull { it.bestCombo } ?: 0

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Slate900,
                        Slate800,
                        Slate950
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // TOP BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onNavigate(AppScreen.MENU) },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Slate900.copy(alpha = 0.8f), CircleShape)
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)), CircleShape)
                        .testTag("leaderboard_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Ortga",
                        tint = Color.White
                    )
                }

                Text(
                    text = "REKORDLAR JADVALI",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                Box(modifier = Modifier.size(40.dp))
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp)
            ) {
                // OVERVIEW STATS CARD
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate900.copy(alpha = 0.8f)),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LeaderboardStatItem(label = "Eng zo‘r ball", value = "$bestScore", color = AmberGlow)
                            LeaderboardStatItem(label = "Eng uzun masofa", value = "${bestDistance}m", color = BlueElectric)
                            LeaderboardStatItem(label = "Eng katta combo", value = "$bestCombo🔥", color = OrangeCombo)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                if (topRecords.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Slate900.copy(alpha = 0.75f)),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(text = "🏃‍♂️", fontSize = 40.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Hozircha natijalar yo‘q",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "O‘yinni boshlang va birinchi rekordni o‘rnating!",
                                    fontSize = 12.sp,
                                    color = Slate400
                                )
                            }
                        }
                    }
                } else {
                    itemsIndexed(topRecords) { index, record ->
                        val rankEmoji = when (index) {
                            0 -> "🥇"
                            1 -> "🥈"
                            2 -> "🥉"
                            else -> "#${index + 1}"
                        }
                        val rankColor = when (index) {
                            0 -> AmberGlow
                            1 -> Slate300
                            2 -> Color(0xFFB45309)
                            else -> Color.White
                        }

                        val dateStr = try {
                            val sdf = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
                            sdf.format(Date(record.timestamp))
                        } catch (_: Exception) { "" }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("leaderboard_row_$index"),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (index < 3) Slate800 else Slate900.copy(alpha = 0.75f)
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (index == 0) AmberGlow.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.1f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = rankEmoji,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = rankColor
                                    )
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column {
                                        Text(
                                            text = "${record.score} ball",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "${record.mode} • ${record.distanceMeters}m • 🪙+${record.coins}",
                                            fontSize = 11.sp,
                                            color = Slate400
                                        )
                                    }
                                }

                                Text(
                                    text = dateStr,
                                    fontSize = 11.sp,
                                    color = Slate400
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LeaderboardStatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = color,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = Slate400
        )
    }
}

