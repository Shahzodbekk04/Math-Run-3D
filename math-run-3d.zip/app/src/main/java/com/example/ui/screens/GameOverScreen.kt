package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlayerProfileEntity
import com.example.game.engine.AppScreen
import com.example.game.engine.GameUiState
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.BlueElectric
import com.example.ui.theme.CrimsonNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.OrangeCombo
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@Composable
fun GameOverScreen(
    uiState: GameUiState,
    profile: PlayerProfileEntity?,
    onRestart: () -> Unit,
    onNavigate: (AppScreen) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "record_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val xpGained = uiState.score / 5 + uiState.correctAnswersCount * 15 + uiState.coinsEarned * 2
    val currentLevel = profile?.level ?: 1
    val currentXp = profile?.xp ?: 0
    val xpProgress = ((currentXp % 500) / 500f).coerceIn(0f, 1f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Slate900,
                        Slate800,
                        Slate950
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(top = 24.dp, bottom = 32.dp)
        ) {
            // 1. GAME OVER HEADER
            item {
                Text(
                    text = "O‘YIN TUGADI",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = CrimsonNeon,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))

                if (uiState.showNewRecordBanner) {
                    Surface(
                        color = AmberGlow,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .scale(pulseScale)
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = "🏆 YANGI REKORD!",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate950,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                } else {
                    Text(
                        text = "Yaxshi harakat! Yana mashq qiling!",
                        fontSize = 13.sp,
                        color = Slate400
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            // 2. MAIN RESULTS SUMMARY CARD
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 500.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900.copy(alpha = 0.85f)),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Score Display Big
                        Text(
                            text = "BALL",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate400,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "${uiState.score}",
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Stats Grid 2x3
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ResultStatBox(
                                    label = "Tangalar",
                                    value = "+${uiState.coinsEarned}",
                                    icon = "🪙",
                                    color = AmberGlow,
                                    modifier = Modifier.weight(1f)
                                )
                                ResultStatBox(
                                    label = "To‘g‘ri javob",
                                    value = "${uiState.correctAnswersCount}",
                                    icon = "✅",
                                    color = EmeraldNeon,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ResultStatBox(
                                    label = "Xatolar",
                                    value = "${uiState.wrongAnswersCount}",
                                    icon = "❌",
                                    color = CrimsonNeon,
                                    modifier = Modifier.weight(1f)
                                )
                                ResultStatBox(
                                    label = "Eng zo‘r Combo",
                                    value = "${uiState.bestCombo}",
                                    icon = "🔥",
                                    color = OrangeCombo,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            ResultStatBox(
                                label = "Bosib o‘tilgan masofa",
                                value = "${uiState.distanceMeters} metr",
                                icon = "🏃",
                                color = BlueElectric,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // XP and Level Progress Bar
                        Surface(
                            color = Slate800.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "LVL $currentLevel",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = BlueElectric
                                    )
                                    Text(
                                        text = "+$xpGained XP",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = EmeraldNeon
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { xpProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = BlueElectric,
                                    trackColor = Slate700
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            // 3. ACTION BUTTONS (RESTART, MAIN MENU, SKINS)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 500.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Play Again Button (Primary)
                    Button(
                        onClick = onRestart,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("game_over_restart_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Slate950, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "QAYTA O‘YNASH",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black,
                                color = Slate950,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    // Main Menu Button
                    Button(
                        onClick = { onNavigate(AppScreen.MENU) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("game_over_menu_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Home, contentDescription = null, tint = Slate400, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "BOSH MENYU",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Slate300
                            )
                        }
                    }

                    // Skins Button
                    Button(
                        onClick = { onNavigate(AppScreen.SKINS) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                        border = BorderStroke(1.dp, Color(0xFFEC4899).copy(alpha = 0.5f))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = Color(0xFFEC4899), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SKINLAR DO‘KONI",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ResultStatBox(
    label: String,
    value: String,
    icon: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Slate800.copy(alpha = 0.5f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = icon, fontSize = 16.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = label,
                    fontSize = 12.sp,
                    color = Slate400,
                    fontWeight = FontWeight.Medium
                )
            }
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

