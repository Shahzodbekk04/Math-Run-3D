package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.game.engine.AppScreen
import com.example.game.engine.Game3DRenderer
import com.example.game.engine.GameUiState
import com.example.game.engine.GameViewModel
import com.example.game.engine.RunState
import com.example.game.model.PowerUpType
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.BlueElectric
import com.example.ui.theme.CrimsonNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.OrangeCombo
import com.example.ui.theme.PurpleNeon
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import kotlinx.coroutines.isActive
import kotlin.math.abs

@Composable
fun GameScreen(
    viewModel: GameViewModel,
    uiState: GameUiState,
    onNavigate: (AppScreen) -> Unit
) {
    var dragAccumX by remember { mutableFloatStateOf(0f) }
    var dragAccumY by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        viewModel.ensureGameRunning()
    }

    // 60 FPS Hardware VSYNC rendering tick for smooth 3D graphics
    var renderTick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(uiState.runState, uiState.isPaused) {
        if (uiState.runState == RunState.RUNNING && !uiState.isPaused) {
            while (isActive) {
                withFrameNanos { renderTick = it }
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. 3D GAME CANVAS WITH GESTURE DETECTION (Isolated from overlay HUD and control buttons)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("game_3d_canvas")
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = {
                            dragAccumX = 0f
                            dragAccumY = 0f
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            dragAccumX += dragAmount.x
                            dragAccumY += dragAmount.y

                            val threshold = 18f
                            if (abs(dragAccumX) > threshold || abs(dragAccumY) > threshold) {
                                if (abs(dragAccumX) > abs(dragAccumY)) {
                                    if (dragAccumX > 0) viewModel.onSwipeRight() else viewModel.onSwipeLeft()
                                } else {
                                    if (dragAccumY > 0) viewModel.onSwipeDown() else viewModel.onSwipeUp()
                                }
                                dragAccumX = 0f
                                dragAccumY = 0f
                            }
                        }
                    )
                }
        ) {
            @Suppress("UNUSED_VARIABLE")
            val tick = renderTick // Read VSYNC state to trigger smooth hardware redraws

            val activeShield = uiState.activePowerUps.any { it.type == PowerUpType.SHIELD }
            val activeMagnet = uiState.activePowerUps.any { it.type == PowerUpType.MAGNET }
            val activeDoubleCoins = uiState.activePowerUps.any { it.type == PowerUpType.DOUBLE_COINS } ||
                    uiState.activeEvent?.name == "DOUBLE_COINS"

            Game3DRenderer.render(
                drawScope = this,
                worldType = uiState.currentWorld,
                skin = uiState.selectedSkin,
                playerLaneX = viewModel.currentLaneX,
                playerY = viewModel.playerY,
                isJumping = viewModel.isJumping,
                isSliding = viewModel.isSliding,
                isTripped = viewModel.isTripped,
                runDistance = viewModel.runDistance,
                activeQuestion = uiState.activeQuestion,
                gateZ = viewModel.gateZ,
                coins = viewModel.coinsList,
                obstacles = viewModel.obstaclesList,
                powerUpPickups = viewModel.powerUpPickupsList,
                particles = viewModel.particlesList,
                floatingTexts = viewModel.floatingTextsList,
                activeShield = activeShield,
                activeMagnet = activeMagnet,
                activeDoubleCoins = activeDoubleCoins,
                isInvincible = viewModel.invincibleTimer > 0f,
                screenShakeOffset = viewModel.screenShakeOffset,
                camTilt = (viewModel.targetLaneX - viewModel.currentLaneX) * 5f
            )
        }

        // 2. TOP IMMERSIVE HUD (Frosted Glass Header & Question Card)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Immersive Header Bar: Coins with Amber Glow, Timer Pill, Score Pill, Pause Button
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                color = Slate900.copy(alpha = 0.55f),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Coins counter and Lives indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = AmberGlow,
                            modifier = Modifier.size(28.dp),
                            shadowElevation = 6.dp
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(text = "🪙", fontSize = 14.sp)
                            }
                        }
                        Text(
                            text = "${uiState.coinsEarned}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = AmberGlow
                        )

                        // Lives Hearts
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            for (i in 1..uiState.maxLives) {
                                val isFilled = i <= uiState.lives
                                Text(
                                    text = if (isFilled) "❤️" else "🖤",
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }

                    // Countdown Timer Pill (Immersive UI Pill)
                    val timeSec = uiState.questionTimeRemainingSec
                    Surface(
                        color = when {
                            timeSec <= 3f -> CrimsonNeon.copy(alpha = 0.25f)
                            timeSec <= 6f -> AmberGlow.copy(alpha = 0.25f)
                            else -> BlueElectric.copy(alpha = 0.2f)
                        },
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(
                            1.dp,
                            when {
                                timeSec <= 3f -> CrimsonNeon.copy(alpha = 0.5f)
                                timeSec <= 6f -> AmberGlow.copy(alpha = 0.5f)
                                else -> BlueElectric.copy(alpha = 0.4f)
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "VAQT:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = when {
                                    timeSec <= 3f -> CrimsonNeon
                                    timeSec <= 6f -> AmberGlow
                                    else -> BlueElectric
                                },
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = String.format("%04.1fs", timeSec),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = when {
                                    timeSec <= 3f -> CrimsonNeon
                                    timeSec <= 6f -> AmberGlow
                                    else -> Color.White
                                }
                            )
                        }
                    }

                    // Score & Distance Display
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "${uiState.score}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "• ${uiState.distanceMeters}m",
                            fontSize = 11.sp,
                            color = Slate400
                        )

                        // Pause Button
                        IconButton(
                            onClick = { viewModel.togglePause() },
                            modifier = Modifier
                                .size(32.dp)
                                .background(Slate800.copy(alpha = 0.85f), CircleShape)
                                .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                                .testTag("pause_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Pauza",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // IMMERSIVE QUESTION CARD (Frosted Glass with glowing header, bold formula and combo)
            val question = uiState.activeQuestion
            if (question != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .widthIn(max = 480.dp)
                        .testTag("math_question_card")
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Slate900.copy(alpha = 0.85f)
                        ),
                        border = BorderStroke(
                            width = 1.dp,
                            color = Color.White.copy(alpha = 0.15f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Top glowing blue accent line
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.5f)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(1.5.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                Color.Transparent,
                                                BlueElectric,
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Mode Title Tag (Uppercase with wide tracking)
                            Text(
                                text = "${uiState.selectedMode.titleUz.uppercase()} • SAVOL ${uiState.questionNumber}/${uiState.totalQuestionsTarget}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = BlueElectric,
                                letterSpacing = 2.sp
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Hero Math Question Formula
                            Text(
                                text = question.questionText,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = (-0.5).sp,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // 3 Step Indicator Dots
                            val progress = (uiState.questionTimeRemainingSec / uiState.questionTotalTimeSec).coerceIn(0f, 1f)
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val activeDots = (progress * 3).toInt().coerceIn(0, 3)
                                repeat(3) { index ->
                                    Box(
                                        modifier = Modifier
                                            .height(5.dp)
                                            .width(28.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(
                                                if (index < activeDots) BlueElectric else BlueElectric.copy(alpha = 0.2f)
                                            )
                                    )
                                }
                            }
                        }
                    }

                    // Floating Angled Combo Badge
                    if (uiState.currentCombo >= 2) {
                        Surface(
                            color = OrangeCombo,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .rotate(10f)
                                .shadow(8.dp, RoundedCornerShape(10.dp))
                        ) {
                            Text(
                                text = "🔥 x${uiState.currentCombo} COMBO",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }

        // 3. LEFT DOCKED POWER-UPS BAR (Immersive UI Floating Dock)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 14.dp, top = 140.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Surface(
                color = Slate900.copy(alpha = 0.75f),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val activeShield = uiState.activePowerUps.any { it.type == PowerUpType.SHIELD }
                    val activeMagnet = uiState.activePowerUps.any { it.type == PowerUpType.MAGNET }
                    val activeDoubleCoins = uiState.activePowerUps.any { it.type == PowerUpType.DOUBLE_COINS } ||
                            uiState.activeEvent?.name == "DOUBLE_COINS"

                    PowerUpDockIcon(
                        emoji = "🛡️",
                        isActive = activeShield,
                        glowColor = BlueElectric
                    )
                    PowerUpDockIcon(
                        emoji = "🧲",
                        isActive = activeMagnet,
                        glowColor = PurpleNeon
                    )
                    PowerUpDockIcon(
                        emoji = "🪙",
                        isActive = activeDoubleCoins,
                        glowColor = AmberGlow
                    )
                }
            }
        }

        // 4. BOTTOM ACTION & DIRECTION CONTROLS (Intuitive Lane Navigation Buttons)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 12.dp, start = 14.dp, end = 14.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 500.dp)
            ) {
                // 3-Lane Direct Selector / Arrow Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ImmersiveControlButton(
                        icon = Icons.Default.ArrowBack,
                        label = "CHAP",
                        accentColor = BlueElectric,
                        tag = "virtual_left",
                        onClick = { viewModel.setLane(0) }
                    )
                    ImmersiveControlButton(
                        icon = Icons.Default.ArrowUpward,
                        label = "O‘RTA",
                        accentColor = EmeraldNeon,
                        tag = "virtual_center",
                        onClick = { viewModel.setLane(1) }
                    )
                    ImmersiveControlButton(
                        icon = Icons.Default.ArrowForward,
                        label = "O‘NG",
                        accentColor = BlueElectric,
                        tag = "virtual_right",
                        onClick = { viewModel.setLane(2) }
                    )
                }
            }
        }

        // 5. INTERACTIVE TUTORIAL OVERLAY
        if (uiState.showTutorial) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Slate950.copy(alpha = 0.88f))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 420.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    border = BorderStroke(1.dp, BlueElectric.copy(alpha = 0.6f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "🎮 O‘YIN QOIDALARI",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        TutorialStepRow(emoji = "👈 👉", text = "Ekranni suring yoki pastdagi tugmalarni bosing")
                        Spacer(modifier = Modifier.height(10.dp))
                        TutorialStepRow(emoji = "🎯", text = "Matematik savolga to‘g‘ri javob berilgan yo‘lakni tanlang!")
                        Spacer(modifier = Modifier.height(10.dp))
                        TutorialStepRow(emoji = "🪙 🧲", text = "Yo‘l-yo‘lakay tangalar va bonuslarni to‘plang!")
                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = { viewModel.completeTutorial() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("tutorial_confirm_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                        ) {
                            Text(
                                text = "TUSHUNDIM, BOSHLADIK!",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = Slate950
                            )
                        }
                    }
                }
            }
        }

        // 6. COMPREHENSIVE OVERLAY PAUSE MENU (Full-screen Frosted Overlay)
        AnimatedVisibility(
            visible = uiState.isPaused,
            enter = fadeIn() + scaleIn(initialScale = 0.92f),
            exit = fadeOut() + scaleOut(targetScale = 0.92f)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Slate950.copy(alpha = 0.92f))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 440.dp)
                        .testTag("pause_overlay_card"),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900.copy(alpha = 0.96f)),
                    border = BorderStroke(1.5.dp, AmberGlow.copy(alpha = 0.6f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Title
                        Surface(
                            shape = CircleShape,
                            color = AmberGlow.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, AmberGlow.copy(alpha = 0.4f)),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = "⏸️ O‘YIN TO‘XTATILDI",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = AmberGlow,
                                letterSpacing = 1.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }

                        // Mode & World subtitle
                        Text(
                            text = "${uiState.selectedMode.titleUz} • ${uiState.currentWorld.nameUz}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Slate400
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Stats Summary Grid (2x2)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PauseStatBox(
                                modifier = Modifier.weight(1f),
                                label = "BALL",
                                value = "${uiState.score}",
                                icon = "🏆",
                                color = AmberGlow
                            )
                            PauseStatBox(
                                modifier = Modifier.weight(1f),
                                label = "TANGALAR",
                                value = "+${uiState.coinsEarned}",
                                icon = "🪙",
                                color = Color(0xFFFBBF24)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PauseStatBox(
                                modifier = Modifier.weight(1f),
                                label = "MASOFA",
                                value = "${uiState.distanceMeters}m",
                                icon = "🏃",
                                color = BlueElectric
                            )
                            PauseStatBox(
                                modifier = Modifier.weight(1f),
                                label = "MAX COMBO",
                                value = "${uiState.bestCombo}x",
                                icon = "🔥",
                                color = CrimsonNeon
                            )
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        // 1. Resume Button (Primary Glowing Emerald/Blue)
                        Button(
                            onClick = { viewModel.resumeGame() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("resume_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Davom ettirish",
                                    tint = Slate950,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "DAVOM ETTIRISH",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Slate950,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 2. Restart Button
                        Button(
                            onClick = { viewModel.restartCurrentGame() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("restart_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                            border = BorderStroke(1.dp, BlueElectric.copy(alpha = 0.4f))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Qayta boshlash",
                                    tint = BlueElectric,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "QAYTA BOSHLASH",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 3. Return to Main Menu Button
                        Button(
                            onClick = { viewModel.quitToMainMenu() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("main_menu_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Slate800.copy(alpha = 0.7f)),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Home,
                                    contentDescription = "Bosh menyu",
                                    tint = Slate400,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "BOSH MENYUGA QAYTISH",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE2E8F0)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PauseStatBox(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    icon: String,
    color: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Slate800.copy(alpha = 0.75f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = icon, fontSize = 20.sp)
            Column {
                Text(
                    text = label,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate400,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = value,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = color
                )
            }
        }
    }
}

@Composable
fun PowerUpDockIcon(
    emoji: String,
    isActive: Boolean,
    glowColor: Color
) {
    Surface(
        color = if (isActive) glowColor.copy(alpha = 0.25f) else Slate800.copy(alpha = 0.4f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(
            1.dp,
            if (isActive) glowColor else Color.White.copy(alpha = 0.1f)
        ),
        modifier = Modifier.size(36.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = emoji,
                fontSize = 16.sp,
                modifier = Modifier.then(
                    if (!isActive) Modifier.scale(0.8f) else Modifier
                )
            )
        }
    }
}

@Composable
fun ImmersiveControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    accentColor: Color = Color.White,
    tag: String,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    Surface(
        onClick = onClick,
        modifier = Modifier
            .size(width = 74.dp, height = 66.dp)
            .scale(if (isPressed) 0.90f else 1.0f)
            .testTag(tag)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        onClick()
                        tryAwaitRelease()
                        isPressed = false
                    }
                )
            },
        shape = RoundedCornerShape(20.dp),
        color = Slate900.copy(alpha = 0.94f),
        border = BorderStroke(2.5.dp, accentColor.copy(alpha = 0.85f)),
        shadowElevation = 10.dp
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(2.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(30.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun TutorialStepRow(emoji: String, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = emoji, fontSize = 20.sp)
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            fontSize = 13.sp,
            color = Slate300,
            fontWeight = FontWeight.Medium
        )
    }
}

