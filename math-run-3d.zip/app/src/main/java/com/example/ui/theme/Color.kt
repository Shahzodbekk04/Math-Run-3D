package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Palette
val Slate950 = Color(0xFF020617)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate100 = Color(0xFFF1F5F9)

// Neon & Glow Accents
val AmberGlow = Color(0xFFFBBF24)
val AmberGlowDark = Color(0xFFD97706)
val BlueElectric = Color(0xFF38BDF8)
val BlueElectricDark = Color(0xFF0284C7)
val EmeraldNeon = Color(0xFF34D399)
val EmeraldNeonDark = Color(0xFF059669)
val CrimsonNeon = Color(0xFFF87171)
val CrimsonNeonDark = Color(0xFFDC2626)
val PurpleNeon = Color(0xFFA855F7)
val OrangeCombo = Color(0xFFF97316)

// Standard theme aliases
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

