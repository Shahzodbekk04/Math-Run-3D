package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlayerProfileEntity
import com.example.game.engine.AppScreen
import com.example.game.engine.GameUiState
import com.example.game.model.SkinItem
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.BlueElectric
import com.example.ui.theme.CrimsonNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@Composable
fun SkinsShopScreen(
    uiState: GameUiState,
    profile: PlayerProfileEntity?,
    onBuySkin: (SkinItem) -> Unit,
    onEquipSkin: (SkinItem) -> Unit,
    onNavigate: (AppScreen) -> Unit
) {
    val totalCoins = profile?.totalCoins ?: 150
    val playerLevel = profile?.level ?: 1
    var previewSkin by remember { mutableStateOf(uiState.selectedSkin) }

    val infiniteTransition = rememberInfiniteTransition(label = "char_bobbing")
    val bobbingAnim by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bobbing"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Slate900,
                        Slate800,
                        Slate950
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // TOP BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onNavigate(AppScreen.MENU) },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Slate900.copy(alpha = 0.8f), CircleShape)
                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)), CircleShape)
                        .testTag("skins_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Ortga",
                        tint = Color.White
                    )
                }

                Text(
                    text = "SKINLAR DO‘KONI",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                // Coin Pill
                Surface(
                    color = Slate900.copy(alpha = 0.8f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, AmberGlow.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🪙", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$totalCoins",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = AmberGlow
                        )
                    }
                }
            }

            // 3D CHARACTER PREVIEW PODIUM
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(180.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Slate900.copy(alpha = 0.8f)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val centerX = size.width * 0.5f
                        val centerY = size.height * 0.65f + bobbingAnim

                        // Glowing Podium Disc
                        drawOval(
                            brush = Brush.radialGradient(
                                colors = listOf(previewSkin.accentColor.copy(alpha = 0.5f), Color(0x00000000))
                            ),
                            topLeft = Offset(centerX - 80f, centerY + 30f),
                            size = Size(160f, 40f)
                        )
                        drawOval(
                            color = Slate800,
                            topLeft = Offset(centerX - 60f, centerY + 35f),
                            size = Size(120f, 25f)
                        )

                        // 3D Humanoid Preview Body
                        // Legs
                        drawLine(
                            color = previewSkin.secondaryColor,
                            start = Offset(centerX - 12f, centerY + 5f),
                            end = Offset(centerX - 14f, centerY + 40f),
                            strokeWidth = 10f
                        )
                        drawLine(
                            color = previewSkin.secondaryColor,
                            start = Offset(centerX + 12f, centerY + 5f),
                            end = Offset(centerX + 14f, centerY + 40f),
                            strokeWidth = 10f
                        )
                        // Torso
                        drawRoundRect(
                            color = previewSkin.primaryColor,
                            topLeft = Offset(centerX - 24f, centerY - 35f),
                            size = Size(48f, 42f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                        )
                        // Backpack
                        drawRect(
                            color = previewSkin.accentColor,
                            topLeft = Offset(centerX - 16f, centerY - 28f),
                            size = Size(32f, 24f)
                        )
                        // Arms
                        drawLine(
                            color = previewSkin.primaryColor,
                            start = Offset(centerX - 24f, centerY - 30f),
                            end = Offset(centerX - 35f, centerY - 5f),
                            strokeWidth = 8f
                        )
                        drawLine(
                            color = previewSkin.primaryColor,
                            start = Offset(centerX + 24f, centerY - 30f),
                            end = Offset(centerX + 35f, centerY - 5f),
                            strokeWidth = 8f
                        )
                        // Head
                        drawCircle(
                            color = previewSkin.helmetColor,
                            radius = 20f,
                            center = Offset(centerX, centerY - 55f)
                        )
                        // Visor
                        drawRoundRect(
                            color = previewSkin.accentColor,
                            topLeft = Offset(centerX - 14f, centerY - 62f),
                            size = Size(28f, 14f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                        )
                    }

                    // Skin Name on Preview Card
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = previewSkin.nameUz,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = previewSkin.descUz,
                            fontSize = 12.sp,
                            color = Slate400
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // SKINS LIST
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(SkinItem.ALL_SKINS) { skin ->
                    val isUnlocked = uiState.unlockedSkins.contains(skin.id)
                    val isEquipped = uiState.selectedSkin.id == skin.id
                    val isLevelMet = playerLevel >= skin.requiredLevel
                    val canAfford = totalCoins >= skin.costCoins

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { previewSkin = skin }
                            .testTag("skin_item_${skin.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (previewSkin.id == skin.id) Slate800 else Slate900.copy(alpha = 0.75f)
                        ),
                        border = BorderStroke(
                            width = if (isEquipped) 1.5.dp else 1.dp,
                            color = if (isEquipped) BlueElectric else Color.White.copy(alpha = 0.1f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Color Badge & Info
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(skin.primaryColor, CircleShape)
                                        .border(2.dp, skin.accentColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isEquipped) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                                    } else if (!isUnlocked) {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = skin.nameUz,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = Slate800,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = "LVL ${skin.requiredLevel}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isLevelMet) BlueElectric else CrimsonNeon,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = skin.descUz,
                                        fontSize = 12.sp,
                                        color = Slate400
                                    )
                                }
                            }

                            // Action Button (Taqish / Sotib olish)
                            when {
                                isEquipped -> {
                                    Surface(
                                        color = EmeraldNeon.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, EmeraldNeon)
                                    ) {
                                        Text(
                                            text = "TAQILGAN",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Black,
                                            color = EmeraldNeon,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                                isUnlocked -> {
                                    Button(
                                        onClick = {
                                            onEquipSkin(skin)
                                            previewSkin = skin
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                                    ) {
                                        Text(text = "TAQISH", fontWeight = FontWeight.Black, fontSize = 12.sp)
                                    }
                                }
                                else -> {
                                    Button(
                                        onClick = {
                                            if (canAfford && isLevelMet) {
                                                onBuySkin(skin)
                                                previewSkin = skin
                                            }
                                        },
                                        enabled = canAfford && isLevelMet,
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = AmberGlow,
                                            disabledContainerColor = Slate800
                                        )
                                    ) {
                                        Text(
                                            text = "🪙 ${skin.costCoins}",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 12.sp,
                                            color = if (canAfford && isLevelMet) Slate950 else Slate400
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

