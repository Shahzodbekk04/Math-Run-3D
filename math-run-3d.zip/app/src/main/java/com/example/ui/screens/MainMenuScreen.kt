package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlayerProfileEntity
import com.example.game.engine.AppScreen
import com.example.game.engine.GameUiState
import com.example.game.model.MathMode
import com.example.game.model.WorldType
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.BlueElectric
import com.example.ui.theme.CrimsonNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PurpleNeon
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@Composable
fun MainMenuScreen(
    uiState: GameUiState,
    profile: PlayerProfileEntity?,
    onStartGame: (MathMode) -> Unit,
    onNavigate: (AppScreen) -> Unit,
    onSelectWorld: (WorldType) -> Unit
) {
    val totalCoins = profile?.totalCoins ?: 150
    val xp = profile?.xp ?: 0
    val level = profile?.level ?: 1
    val xpInCurrentLevel = xp % 500
    val xpProgress = (xpInCurrentLevel / 500f).coerceIn(0f, 1f)

    val levelTitle = when {
        level <= 1 -> "Beginner"
        level <= 2 -> "Rookie"
        level <= 3 -> "Smart Runner"
        level <= 4 -> "Math Master"
        else -> "Math Champion"
    }

    val infiniteTransition = rememberInfiniteTransition(label = "title_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Slate900,
                        Slate800,
                        Slate950
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
        ) {
            // 1. TOP HEADER: Profile Stats (Level, XP, Coins)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Level & XP Pill (Immersive UI Style)
                    Surface(
                        color = Slate900.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(BlueElectric),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$level",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = Slate950
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "LVL $level • $levelTitle",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                LinearProgressIndicator(
                                    progress = { xpProgress },
                                    modifier = Modifier
                                        .width(84.dp)
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = BlueElectric,
                                    trackColor = Slate700
                                )
                            }
                        }
                    }

                    // Coins Counter Pill with Monospace Font & Amber Glow
                    Surface(
                        color = Slate900.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, AmberGlow.copy(alpha = 0.4f)),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = AmberGlow,
                                modifier = Modifier.size(22.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = "🪙", fontSize = 11.sp)
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$totalCoins",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                color = AmberGlow
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(18.dp))
            }

            // 2. HERO TITLE & LOGO
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.scale(pulseScale)
                ) {
                    Text(
                        text = "MATH RUN 3D",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "🎮 3D MATEMATIK ENDLESS RUNNER",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlueElectric,
                        letterSpacing = 1.5.sp
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            // 3. MAIN "O'YINNI BOSHLASH" BUTTON (Immersive Glow Pill)
            item {
                Button(
                    onClick = { onStartGame(uiState.selectedMode) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp)
                        .height(58.dp)
                        .testTag("play_button"),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2563EB)
                    ),
                    border = BorderStroke(1.dp, BlueElectric.copy(alpha = 0.5f)),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "O‘yinni boshlash",
                            tint = Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "O‘YINNI BOSHLASH",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 1.5.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(22.dp))
            }

            // 4. MATHEMATICS MODE CARDS SECTION HEADER
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp),
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = "MATEMATIKA REJIMLARI",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = Slate400,
                        letterSpacing = 1.5.sp
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // 5. 4 BIG MODE CARDS (+ QO'SHISH, − AYIRISH, × KO'PAYTIRISH, ÷ BO'LISH)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ImmersiveModeCard(
                        mode = MathMode.ADDITION,
                        accentColor = EmeraldNeon,
                        gradientColors = listOf(Color(0xFF064E3B), Color(0xFF065F46), Color(0xFF047857)),
                        examples = "5 + 5 • 10 + 10 • 25 + 13 • 40 + 20",
                        onClick = { onStartGame(MathMode.ADDITION) }
                    )

                    ImmersiveModeCard(
                        mode = MathMode.SUBTRACTION,
                        accentColor = BlueElectric,
                        gradientColors = listOf(Color(0xFF0C4A6E), Color(0xFF075985), Color(0xFF0284C7)),
                        examples = "10 − 5 • 20 − 8 • 50 − 25 • 100 − 45",
                        onClick = { onStartGame(MathMode.SUBTRACTION) }
                    )

                    ImmersiveModeCard(
                        mode = MathMode.MULTIPLICATION,
                        accentColor = AmberGlow,
                        gradientColors = listOf(Color(0xFF713F12), Color(0xFF854D0E), Color(0xFFB45309)),
                        examples = "2 × 5 • 5 × 10 • 10 × 8 • 12 × 15",
                        onClick = { onStartGame(MathMode.MULTIPLICATION) }
                    )

                    ImmersiveModeCard(
                        mode = MathMode.DIVISION,
                        accentColor = PurpleNeon,
                        gradientColors = listOf(Color(0xFF3B0764), Color(0xFF581C87), Color(0xFF6B21A8)),
                        examples = "10 ÷ 2 • 25 ÷ 5 • 48 ÷ 6 • 100 ÷ 10",
                        onClick = { onStartGame(MathMode.DIVISION) }
                    )

                    ImmersiveModeCard(
                        mode = MathMode.MIXED,
                        accentColor = CrimsonNeon,
                        gradientColors = listOf(Color(0xFF831843), Color(0xFF9D174D), Color(0xFFBE185D)),
                        examples = "(5 × 4) + 10 • 50 − (6 × 5) • 6² + 14 • ? + 25 = 60",
                        onClick = { onStartGame(MathMode.MIXED) }
                    )
                }
                Spacer(modifier = Modifier.height(22.dp))
            }

            // 6. ENVIRONMENT SELECTOR (5 WORLDS)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp)
                ) {
                    Text(
                        text = "3D MUHITLAR",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = Slate400,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        WorldType.values().forEach { world ->
                            val isSelected = uiState.currentWorld == world
                            Surface(
                                color = if (isSelected) Slate800 else Slate900.copy(alpha = 0.75f),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) BlueElectric else Color.White.copy(alpha = 0.1f)
                                ),
                                modifier = Modifier
                                    .clickable { onSelectWorld(world) }
                                    .padding(vertical = 2.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = world.emoji, fontSize = 20.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = world.nameUz,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) BlueElectric else Color.White
                                        )
                                        Text(
                                            text = world.descUz,
                                            fontSize = 10.sp,
                                            color = Slate400
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(22.dp))
            }

            // 7. BOTTOM NAVIGATION TILES (SKINS, UPGRADES, LEADERBOARD, SETTINGS)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ImmersiveMenuTile(
                        icon = Icons.Default.ShoppingBag,
                        label = "SKINLAR",
                        badge = "7",
                        color = Color(0xFFEC4899),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(AppScreen.SKINS) }
                    )
                    ImmersiveMenuTile(
                        icon = Icons.Default.Stars,
                        label = "UPGRADE",
                        badge = "MAX",
                        color = AmberGlow,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(AppScreen.UPGRADES) }
                    )
                    ImmersiveMenuTile(
                        icon = Icons.Default.EmojiEvents,
                        label = "REKORD",
                        badge = "TOP",
                        color = EmeraldNeon,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(AppScreen.LEADERBOARD) }
                    )
                    ImmersiveMenuTile(
                        icon = Icons.Default.Settings,
                        label = "SOZLASH",
                        badge = "",
                        color = Slate400,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(AppScreen.SETTINGS) }
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun ImmersiveModeCard(
    mode: MathMode,
    accentColor: Color,
    gradientColors: List<Color>,
    examples: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("mode_card_${mode.id.lowercase()}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(gradientColors))
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(18.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = mode.titleUz,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = mode.subtitleUz,
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = examples,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }

                Surface(
                    color = Color.White.copy(alpha = 0.15f),
                    shape = CircleShape,
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "O‘ynash",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ImmersiveMenuTile(
    icon: ImageVector,
    label: String,
    badge: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = Slate900.copy(alpha = 0.8f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
        modifier = modifier
            .height(84.dp)
            .clickable { onClick() }
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                textAlign = TextAlign.Center
            )
        }
    }
}

