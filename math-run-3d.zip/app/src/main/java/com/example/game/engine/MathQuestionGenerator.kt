package com.example.game.engine

import com.example.game.model.DifficultyLevel
import com.example.game.model.MathMode
import com.example.game.model.MathQuestion
import kotlin.random.Random

object MathQuestionGenerator {

    fun generateQuestion(
        questionNumber: Int,
        mode: MathMode,
        extraTimeBonusSec: Float = 0f
    ): MathQuestion {
        val difficulty = when {
            questionNumber <= 4 -> DifficultyLevel.EASY
            questionNumber <= 9 -> DifficultyLevel.MEDIUM
            questionNumber <= 15 -> DifficultyLevel.HARD
            else -> DifficultyLevel.EXPERT
        }

        val questionData = when (mode) {
            MathMode.ADDITION -> generateAddition(difficulty)
            MathMode.SUBTRACTION -> generateSubtraction(difficulty)
            MathMode.MULTIPLICATION -> generateMultiplication(difficulty)
            MathMode.DIVISION -> generateDivision(difficulty)
            MathMode.MIXED -> generateMixed(difficulty)
        }

        val options = generateDistractors(questionData.answer, difficulty)
        val shuffledOptions = options.shuffled()
        val correctIndex = shuffledOptions.indexOf(questionData.answer)
        val totalTime = difficulty.baseTimeSec + extraTimeBonusSec

        return MathQuestion(
            id = questionNumber,
            num1 = questionData.num1,
            num2 = questionData.num2,
            operation = questionData.operation,
            questionText = questionData.text,
            correctAnswer = questionData.answer,
            options = shuffledOptions,
            correctIndex = correctIndex,
            timeLimitSec = totalTime
        )
    }

    private data class QuestionResult(
        val num1: Int,
        val num2: Int,
        val operation: String,
        val answer: Int,
        val text: String
    )

    // ==========================================
    // 1. ADDITION (+ QO'SHISH)
    // ==========================================
    private fun generateAddition(difficulty: DifficultyLevel): QuestionResult {
        val variant = Random.nextInt(0, 3)

        return when (difficulty) {
            DifficultyLevel.EASY -> {
                when (variant) {
                    0 -> { // Single digit + single digit
                        val a = Random.nextInt(2, 12)
                        val b = Random.nextInt(2, 12)
                        QuestionResult(a, b, "+", a + b, "$a + $b = ?")
                    }
                    1 -> { // Tens helper
                        val a = Random.nextInt(1, 9) * 5
                        val b = Random.nextInt(1, 5) * 5
                        QuestionResult(a, b, "+", a + b, "$a + $b = ?")
                    }
                    else -> { // Missing term
                        val a = Random.nextInt(3, 10)
                        val total = a + Random.nextInt(4, 11)
                        val b = total - a
                        QuestionResult(a, b, "+", b, "$a + ? = $total")
                    }
                }
            }
            DifficultyLevel.MEDIUM -> {
                when (variant) {
                    0 -> { // 2-digit + 2-digit
                        val a = Random.nextInt(15, 65)
                        val b = Random.nextInt(12, 45)
                        QuestionResult(a, b, "+", a + b, "$a + $b = ?")
                    }
                    1 -> { // 3 terms
                        val a = Random.nextInt(5, 20)
                        val b = Random.nextInt(5, 20)
                        val c = Random.nextInt(5, 20)
                        val ans = a + b + c
                        QuestionResult(a, b, "+", ans, "$a + $b + $c = ?")
                    }
                    else -> { // Missing term
                        val a = Random.nextInt(20, 50)
                        val total = a + Random.nextInt(15, 45)
                        val b = total - a
                        QuestionResult(a, b, "+", b, "$a + ? = $total")
                    }
                }
            }
            DifficultyLevel.HARD -> {
                when (variant) {
                    0 -> { // 3-digit + 2/3-digit
                        val a = Random.nextInt(100, 450)
                        val b = Random.nextInt(50, 350)
                        QuestionResult(a, b, "+", a + b, "$a + $b = ?")
                    }
                    1 -> { // 3 terms with round numbers
                        val a = Random.nextInt(25, 75)
                        val b = Random.nextInt(25, 75)
                        val c = Random.nextInt(25, 75)
                        val ans = a + b + c
                        QuestionResult(a, b, "+", ans, "$a + $b + $c = ?")
                    }
                    else -> {
                        val a = Random.nextInt(120, 350)
                        val total = a + Random.nextInt(80, 250)
                        val b = total - a
                        QuestionResult(a, b, "+", b, "? + $a = $total")
                    }
                }
            }
            DifficultyLevel.EXPERT -> {
                val a = Random.nextInt(350, 950)
                val b = Random.nextInt(250, 850)
                QuestionResult(a, b, "+", a + b, "$a + $b = ?")
            }
        }
    }

    // ==========================================
    // 2. SUBTRACTION (− AYIRISH)
    // ==========================================
    private fun generateSubtraction(difficulty: DifficultyLevel): QuestionResult {
        val variant = Random.nextInt(0, 3)

        return when (difficulty) {
            DifficultyLevel.EASY -> {
                when (variant) {
                    0 -> {
                        val b = Random.nextInt(2, 10)
                        val a = b + Random.nextInt(2, 12)
                        QuestionResult(a, b, "−", a - b, "$a − $b = ?")
                    }
                    1 -> {
                        val tens = Random.nextInt(2, 6) * 10
                        val b = Random.nextInt(2, 9)
                        QuestionResult(tens, b, "−", tens - b, "$tens − $b = ?")
                    }
                    else -> { // Missing term
                        val a = Random.nextInt(12, 25)
                        val diff = Random.nextInt(3, 10)
                        val ans = a - diff
                        QuestionResult(a, diff, "−", ans, "$a − ? = $diff")
                    }
                }
            }
            DifficultyLevel.MEDIUM -> {
                when (variant) {
                    0 -> {
                        val b = Random.nextInt(15, 48)
                        val a = b + Random.nextInt(15, 55)
                        QuestionResult(a, b, "−", a - b, "$a − $b = ?")
                    }
                    1 -> { // 100 minus something
                        val b = Random.nextInt(15, 85)
                        QuestionResult(100, b, "−", 100 - b, "100 − $b = ?")
                    }
                    else -> {
                        val a = Random.nextInt(50, 95)
                        val diff = Random.nextInt(15, 40)
                        val ans = a - diff
                        QuestionResult(a, diff, "−", ans, "$a − ? = $diff")
                    }
                }
            }
            DifficultyLevel.HARD -> {
                when (variant) {
                    0 -> {
                        val b = Random.nextInt(60, 280)
                        val a = b + Random.nextInt(75, 320)
                        QuestionResult(a, b, "−", a - b, "$a − $b = ?")
                    }
                    1 -> { // Round hundreds: 500 - x
                        val base = Random.nextInt(2, 6) * 100
                        val b = Random.nextInt(45, 185)
                        QuestionResult(base, b, "−", base - b, "$base − $b = ?")
                    }
                    else -> {
                        val a = Random.nextInt(200, 500)
                        val diff = Random.nextInt(60, 180)
                        val ans = a - diff
                        QuestionResult(a, diff, "−", ans, "$a − ? = $diff")
                    }
                }
            }
            DifficultyLevel.EXPERT -> {
                val b = Random.nextInt(250, 750)
                val a = b + Random.nextInt(300, 900)
                QuestionResult(a, b, "−", a - b, "$a − $b = ?")
            }
        }
    }

    // ==========================================
    // 3. MULTIPLICATION (× KO'PAYTIRISH)
    // ==========================================
    private fun generateMultiplication(difficulty: DifficultyLevel): QuestionResult {
        val variant = Random.nextInt(0, 3)

        return when (difficulty) {
            DifficultyLevel.EASY -> {
                when (variant) {
                    0, 1 -> { // Times table 2-9
                        val a = Random.nextInt(2, 10)
                        val b = Random.nextInt(2, 10)
                        QuestionResult(a, b, "×", a * b, "$a × $b = ?")
                    }
                    else -> { // Missing factor
                        val a = Random.nextInt(3, 9)
                        val b = Random.nextInt(3, 9)
                        val prod = a * b
                        QuestionResult(a, b, "×", b, "$a × ? = $prod")
                    }
                }
            }
            DifficultyLevel.MEDIUM -> {
                when (variant) {
                    0 -> { // Double digit x single digit
                        val a = Random.nextInt(11, 18)
                        val b = Random.nextInt(3, 8)
                        QuestionResult(a, b, "×", a * b, "$a × $b = ?")
                    }
                    1 -> { // Perfect Squares: 5^2, 6^2, 7^2, 8^2, 9^2, 10^2, 11^2, 12^2
                        val n = Random.nextInt(4, 13)
                        QuestionResult(n, n, "×", n * n, "$n² = ?")
                    }
                    else -> { // 3 small factors: 2 x 3 x 4
                        val a = Random.nextInt(2, 6)
                        val b = Random.nextInt(2, 5)
                        val c = Random.nextInt(2, 5)
                        val ans = a * b * c
                        QuestionResult(a, b, "×", ans, "$a × $b × $c = ?")
                    }
                }
            }
            DifficultyLevel.HARD -> {
                when (variant) {
                    0 -> { // Double digit x double digit
                        val a = Random.nextInt(12, 25)
                        val b = Random.nextInt(6, 16)
                        QuestionResult(a, b, "×", a * b, "$a × $b = ?")
                    }
                    1 -> { // Higher square: 13^2, 14^2, 15^2, 20^2, 25^2
                        val candidates = listOf(13, 14, 15, 16, 20, 25)
                        val n = candidates.random()
                        QuestionResult(n, n, "×", n * n, "$n² = ?")
                    }
                    else -> { // Tens product: 30 x 15
                        val a = Random.nextInt(2, 9) * 10
                        val b = Random.nextInt(11, 22)
                        QuestionResult(a, b, "×", a * b, "$a × $b = ?")
                    }
                }
            }
            DifficultyLevel.EXPERT -> {
                val a = Random.nextInt(18, 35)
                val b = Random.nextInt(15, 30)
                QuestionResult(a, b, "×", a * b, "$a × $b = ?")
            }
        }
    }

    // ==========================================
    // 4. DIVISION (÷ BO'LISH)
    // ==========================================
    private fun generateDivision(difficulty: DifficultyLevel): QuestionResult {
        val variant = Random.nextInt(0, 3)

        return when (difficulty) {
            DifficultyLevel.EASY -> {
                when (variant) {
                    0, 1 -> {
                        val d = Random.nextInt(2, 9)
                        val q = Random.nextInt(2, 10)
                        val dividend = d * q
                        QuestionResult(dividend, d, "÷", q, "$dividend ÷ $d = ?")
                    }
                    else -> {
                        val d = Random.nextInt(2, 8)
                        val q = Random.nextInt(3, 9)
                        val dividend = d * q
                        QuestionResult(dividend, d, "÷", d, "$dividend ÷ ? = $q")
                    }
                }
            }
            DifficultyLevel.MEDIUM -> {
                when (variant) {
                    0 -> {
                        val d = Random.nextInt(3, 12)
                        val q = Random.nextInt(6, 18)
                        val dividend = d * q
                        QuestionResult(dividend, d, "÷", q, "$dividend ÷ $d = ?")
                    }
                    1 -> { // Round hundred division: 120 / 4, 350 / 7
                        val q = Random.nextInt(2, 9) * 10
                        val d = Random.nextInt(2, 9)
                        val dividend = d * q
                        QuestionResult(dividend, d, "÷", q, "$dividend ÷ $d = ?")
                    }
                    else -> {
                        val d = Random.nextInt(4, 12)
                        val q = Random.nextInt(8, 16)
                        val dividend = d * q
                        QuestionResult(dividend, d, "÷", dividend, "? ÷ $d = $q")
                    }
                }
            }
            DifficultyLevel.HARD -> {
                when (variant) {
                    0 -> {
                        val d = Random.nextInt(12, 25)
                        val q = Random.nextInt(12, 30)
                        val dividend = d * q
                        QuestionResult(dividend, d, "÷", q, "$dividend ÷ $d = ?")
                    }
                    else -> {
                        val d = listOf(15, 20, 25, 30, 50).random()
                        val q = Random.nextInt(10, 35)
                        val dividend = d * q
                        QuestionResult(dividend, d, "÷", q, "$dividend ÷ $d = ?")
                    }
                }
            }
            DifficultyLevel.EXPERT -> {
                val d = Random.nextInt(18, 45)
                val q = Random.nextInt(20, 50)
                val dividend = d * q
                QuestionResult(dividend, d, "÷", q, "$dividend ÷ $d = ?")
            }
        }
    }

    // ==========================================
    // 5. MIXED / ARALASH (⚡ BARCHA AMALLAR)
    // ==========================================
    private fun generateMixed(difficulty: DifficultyLevel): QuestionResult {
        val opPick = Random.nextInt(0, 6)

        return when (opPick) {
            0 -> generateAddition(difficulty)
            1 -> generateSubtraction(difficulty)
            2 -> generateMultiplication(difficulty)
            3 -> generateDivision(difficulty)
            4 -> { // 2-step: (a * b) + c
                val a = Random.nextInt(2, 8)
                val b = Random.nextInt(2, 8)
                val c = Random.nextInt(3, 15)
                val ans = (a * b) + c
                QuestionResult(a, b, "⚡", ans, "($a × $b) + $c = ?")
            }
            else -> { // 2-step: a - (b * c) or (a / b) + c
                if (Random.nextBoolean()) {
                    val b = Random.nextInt(2, 6)
                    val c = Random.nextInt(2, 6)
                    val a = (b * c) + Random.nextInt(5, 25)
                    val ans = a - (b * c)
                    QuestionResult(a, b, "⚡", ans, "$a − ($b × $c) = ?")
                } else {
                    val divisor = Random.nextInt(2, 6)
                    val quotient = Random.nextInt(3, 10)
                    val dividend = divisor * quotient
                    val add = Random.nextInt(5, 20)
                    val ans = quotient + add
                    QuestionResult(dividend, divisor, "⚡", ans, "($dividend ÷ $divisor) + $add = ?")
                }
            }
        }
    }

    // ==========================================
    // Smart Distractors Generator
    // ==========================================
    private fun generateDistractors(correctAnswer: Int, difficulty: DifficultyLevel): List<Int> {
        val distractors = mutableSetOf(correctAnswer)

        // Close plausible deviations
        val deltas = when (difficulty) {
            DifficultyLevel.EASY -> listOf(-2, -1, 1, 2, 3, -3, 5, -5)
            DifficultyLevel.MEDIUM -> listOf(-10, -5, -2, -1, 1, 2, 5, 10, -3, 3)
            DifficultyLevel.HARD -> listOf(-20, -10, -5, -2, 2, 5, 10, 20, 15, -15)
            DifficultyLevel.EXPERT -> listOf(-50, -20, -10, -5, 5, 10, 20, 50, 30, -30)
        }.shuffled()

        for (delta in deltas) {
            val candidate = correctAnswer + delta
            if (candidate > 0 && candidate != correctAnswer) {
                distractors.add(candidate)
            }
            if (distractors.size >= 3) break
        }

        // Fallback offset loop to guarantee exactly 3 distinct positive options
        var offset = 1
        while (distractors.size < 3) {
            val candidate1 = (correctAnswer + offset).coerceAtLeast(1)
            val candidate2 = (correctAnswer - offset).coerceAtLeast(1)
            if (candidate1 != correctAnswer) distractors.add(candidate1)
            if (distractors.size < 3 && candidate2 != correctAnswer) distractors.add(candidate2)
            offset++
        }

        return distractors.take(3)
    }
}
