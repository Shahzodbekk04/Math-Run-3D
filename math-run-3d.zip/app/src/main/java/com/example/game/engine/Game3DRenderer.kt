package com.example.game.engine

import android.graphics.Paint
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import com.example.game.model.FloatingTextEffect
import com.example.game.model.MathQuestion
import com.example.game.model.ObstacleType
import com.example.game.model.Particle3D
import com.example.game.model.PowerUpType
import com.example.game.model.SkinItem
import com.example.game.model.WorldType
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

object Game3DRenderer {

    private val textPaint = Paint().apply {
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    fun render(
        drawScope: DrawScope,
        worldType: WorldType,
        skin: SkinItem,
        playerLaneX: Float,
        playerY: Float,
        isJumping: Boolean,
        isSliding: Boolean,
        isTripped: Boolean,
        runDistance: Float,
        activeQuestion: MathQuestion?,
        gateZ: Float?,
        coins: List<Coin3D>,
        obstacles: List<Obstacle3D>,
        powerUpPickups: List<PowerUpPickup3D>,
        particles: List<Particle3D>,
        floatingTexts: List<FloatingTextEffect>,
        activeShield: Boolean,
        activeMagnet: Boolean,
        activeDoubleCoins: Boolean,
        isInvincible: Boolean = false,
        screenShakeOffset: Offset,
        camTilt: Float
    ) {
        val width = drawScope.size.width
        val height = drawScope.size.height
        val horizonY = height * 0.38f + screenShakeOffset.y
        val centerX = width * 0.5f + screenShakeOffset.x
        val fovX = width * 0.54f
        val fovY = height * 0.54f
        val camY = 1.9f
        val camZ = 0.0f
        val playerZ = 2.4f

        // Helper for true 3D projection (no camera offset dampening)
        fun project(x: Float, y: Float, z: Float): ProjectedPoint? {
            val relZ = z - camZ
            if (relZ <= 0.15f) return null
            val scale = 1.0f / relZ
            val projX = centerX + x * scale * fovX
            val projY = horizonY + (camY - y) * scale * fovY
            return ProjectedPoint(projX, projY, scale, relZ)
        }

        // 1. SKY & HORIZON
        drawScope.drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(worldType.skyColorTop, worldType.skyColorBottom),
                startY = 0f,
                endY = horizonY
            ),
            topLeft = Offset.Zero,
            size = Size(width, horizonY)
        )

        // Scenery background elements on horizon
        drawHorizonScenery(drawScope, worldType, width, horizonY, runDistance)

        // 2. GROUND
        drawScope.drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(worldType.groundColor.copy(alpha = 0.9f), worldType.groundColor),
                startY = horizonY,
                endY = height
            ),
            topLeft = Offset(0f, horizonY),
            size = Size(width, height - horizonY)
        )

        // 3. 3D TRACK / ROAD (Expansive, distinct 3-lane track)
        val trackFarZ = 60.0f
        val trackNearZ = 1.0f
        val trackHalfWidth = 2.25f

        val pNearLeft = project(-trackHalfWidth, 0f, trackNearZ)
        val pNearRight = project(trackHalfWidth, 0f, trackNearZ)
        val pFarLeft = project(-trackHalfWidth, 0f, trackFarZ)
        val pFarRight = project(trackHalfWidth, 0f, trackFarZ)

        if (pNearLeft != null && pNearRight != null && pFarLeft != null && pFarRight != null) {
            val roadPath = Path().apply {
                moveTo(pNearLeft.x, pNearLeft.y)
                lineTo(pFarLeft.x, pFarLeft.y)
                lineTo(pFarRight.x, pFarRight.y)
                lineTo(pNearRight.x, pNearRight.y)
                close()
            }
            drawScope.drawPath(roadPath, color = worldType.trackColor)

            // Segmented scrolling stripes along the road
            val segmentSpacing = 2.5f
            val baseOffset = (runDistance % segmentSpacing)
            var segZ = trackNearZ + (segmentSpacing - baseOffset)
            while (segZ < trackFarZ) {
                val segPLeft = project(-trackHalfWidth, 0f, segZ)
                val segPRight = project(trackHalfWidth, 0f, segZ)
                val nextPLeft = project(-trackHalfWidth, 0f, (segZ + 1.2f).coerceAtMost(trackFarZ))
                val nextPRight = project(trackHalfWidth, 0f, (segZ + 1.2f).coerceAtMost(trackFarZ))

                if (segPLeft != null && segPRight != null && nextPLeft != null && nextPRight != null) {
                    val segPath = Path().apply {
                        moveTo(segPLeft.x, segPLeft.y)
                        lineTo(nextPLeft.x, nextPLeft.y)
                        lineTo(nextPRight.x, nextPRight.y)
                        lineTo(segPRight.x, segPRight.y)
                        close()
                    }
                    drawScope.drawPath(
                        segPath,
                        color = worldType.trackLineColor.copy(alpha = 0.12f)
                    )
                }
                segZ += segmentSpacing
            }

            // Lane Divider Lines (Dividers separating 3 lanes: Left: -1.5, Center: 0.0, Right: +1.5)
            val laneDividers = listOf(-0.75f, 0.75f)
            for (divX in laneDividers) {
                val divNear = project(divX, 0f, trackNearZ)
                val divFar = project(divX, 0f, trackFarZ)
                if (divNear != null && divFar != null) {
                    drawScope.drawLine(
                        color = worldType.trackLineColor.copy(alpha = 0.55f),
                        start = Offset(divNear.x, divNear.y),
                        end = Offset(divFar.x, divFar.y),
                        strokeWidth = 3.5f
                    )
                }
            }

            // Glowing Edge Rails
            val leftNear = project(-trackHalfWidth, 0.1f, trackNearZ)
            val leftFar = project(-trackHalfWidth, 0.1f, trackFarZ)
            val rightNear = project(trackHalfWidth, 0.1f, trackNearZ)
            val rightFar = project(trackHalfWidth, 0.1f, trackFarZ)
            if (leftNear != null && leftFar != null) {
                drawScope.drawLine(
                    color = worldType.accentGlow,
                    start = Offset(leftNear.x, leftNear.y),
                    end = Offset(leftFar.x, leftFar.y),
                    strokeWidth = 4f
                )
            }
            if (rightNear != null && rightFar != null) {
                drawScope.drawLine(
                    color = worldType.accentGlow,
                    start = Offset(rightNear.x, rightNear.y),
                    end = Offset(rightFar.x, rightFar.y),
                    strokeWidth = 4f
                )
            }
        }

        // 4. SCENERY PILLARS & PROPS
        drawSideScenery(drawScope, worldType, runDistance, ::project)

        // 5. 3D OBJECTS (Z-Sorted: Render Far to Near)
        val renderList = mutableListOf<Renderable3D>()

        // Add Gate if active
        if (gateZ != null && gateZ in 0.5f..60f && activeQuestion != null) {
            renderList.add(Renderable3D(gateZ) {
                drawMathGate(drawScope, activeQuestion, gateZ, worldType, ::project)
            })
        }

        // Add Coins
        for (coin in coins) {
            if (coin.z in 0.5f..60f && !coin.isCollected) {
                renderList.add(Renderable3D(coin.z) {
                    drawCoin(drawScope, coin, runDistance, activeDoubleCoins, ::project)
                })
            }
        }

        // Add Obstacles
        for (obs in obstacles) {
            if (obs.z in 0.5f..60f) {
                renderList.add(Renderable3D(obs.z) {
                    drawObstacle(drawScope, obs, worldType, ::project)
                })
            }
        }

        // Add PowerUp Pickups
        for (pickup in powerUpPickups) {
            if (pickup.z in 0.5f..60f && !pickup.isCollected) {
                renderList.add(Renderable3D(pickup.z) {
                    drawPowerUpPickup(drawScope, pickup, runDistance, ::project)
                })
            }
        }

        // Add Character to Z-list
        renderList.add(Renderable3D(playerZ) {
            drawCharacter(
                drawScope = drawScope,
                skin = skin,
                laneX = playerLaneX,
                playerY = playerY,
                playerZ = playerZ,
                isJumping = isJumping,
                isSliding = isSliding,
                isTripped = isTripped,
                isInvincible = isInvincible,
                runDistance = runDistance,
                activeShield = activeShield,
                activeMagnet = activeMagnet,
                project = ::project
            )
        })

        // Sort by Z descending (furthest first)
        renderList.sortByDescending { it.z }
        for (item in renderList) {
            item.drawAction()
        }

        // 6. 3D PARTICLES
        for (p in particles) {
            val proj = project(p.x, p.y, p.z) ?: continue
            val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
            val size = (p.size * proj.scale * fovY * 0.05f).coerceIn(2f, 24f)
            drawScope.drawCircle(
                color = p.color.copy(alpha = alpha),
                radius = size,
                center = Offset(proj.x, proj.y)
            )
        }

        // 7. FLOATING TEXTS
        for (ft in floatingTexts) {
            val proj = project(ft.x, ft.y, ft.z) ?: continue
            textPaint.color = ft.color.toArgb()
            textPaint.alpha = (ft.alpha * 255).toInt().coerceIn(0, 255)
            textPaint.textSize = (32f * ft.scale).coerceIn(18f, 60f)
            drawScope.drawContext.canvas.nativeCanvas.drawText(
                ft.text,
                proj.x,
                proj.y,
                textPaint
            )
        }
    }

    private fun drawHorizonScenery(
        drawScope: DrawScope,
        worldType: WorldType,
        width: Float,
        horizonY: Float,
        runDistance: Float
    ) {
        val sunColor = when (worldType) {
            WorldType.JUNGLE -> Color(0xFFFBBF24)
            WorldType.DESERT -> Color(0xFFFEF08A)
            WorldType.ICE -> Color(0xFFE0F2FE)
            WorldType.LAVA -> Color(0xFFF87171)
            WorldType.CYBER_CITY -> Color(0xFFC084FC)
        }

        // Sun / Moon / Cyber Orb
        drawScope.drawCircle(
            color = sunColor.copy(alpha = 0.7f),
            radius = 35f,
            center = Offset(width * 0.5f, horizonY - 45f)
        )

        // Distant Mountain Silhouettes
        val mountainPath = Path().apply {
            moveTo(0f, horizonY)
            var currX = 0f
            val step = width / 8f
            for (i in 0..8) {
                val peakY = horizonY - ((sin(i * 1.5 + runDistance * 0.005) * 20f + 30f).toFloat())
                lineTo(currX + step * 0.5f, peakY)
                lineTo(currX + step, horizonY)
                currX += step
            }
            close()
        }
        drawScope.drawPath(mountainPath, color = worldType.groundColor.copy(alpha = 0.4f))
    }

    private fun drawSideScenery(
        drawScope: DrawScope,
        worldType: WorldType,
        runDistance: Float,
        project: (Float, Float, Float) -> ProjectedPoint?
    ) {
        val pillarSpacing = 6.0f
        val offset = (runDistance % pillarSpacing)
        var z = 2.0f + (pillarSpacing - offset)

        while (z < 55.0f) {
            val leftPillarBase = project(-2.65f, 0f, z)
            val leftPillarTop = project(-2.65f, 2.5f, z)
            val rightPillarBase = project(2.65f, 0f, z)
            val rightPillarTop = project(2.65f, 2.5f, z)

            if (leftPillarBase != null && leftPillarTop != null) {
                val pillarWidth = (0.28f * leftPillarBase.scale * drawScope.size.width * 1.0f).coerceIn(5f, 45f)
                drawScope.drawRect(
                    color = worldType.pillarColor,
                    topLeft = Offset(leftPillarTop.x - pillarWidth * 0.5f, leftPillarTop.y),
                    size = Size(pillarWidth, leftPillarBase.y - leftPillarTop.y)
                )
                // Pillar Cap Glow
                drawScope.drawCircle(
                    color = worldType.accentGlow.copy(alpha = (1.0f - z / 60f).coerceIn(0.2f, 0.9f)),
                    radius = pillarWidth * 0.6f,
                    center = Offset(leftPillarTop.x, leftPillarTop.y)
                )
            }

            if (rightPillarBase != null && rightPillarTop != null) {
                val pillarWidth = (0.28f * rightPillarBase.scale * drawScope.size.width * 1.0f).coerceIn(5f, 45f)
                drawScope.drawRect(
                    color = worldType.pillarColor,
                    topLeft = Offset(rightPillarTop.x - pillarWidth * 0.5f, rightPillarTop.y),
                    size = Size(pillarWidth, rightPillarBase.y - rightPillarTop.y)
                )
                drawScope.drawCircle(
                    color = worldType.accentGlow.copy(alpha = (1.0f - z / 60f).coerceIn(0.2f, 0.9f)),
                    radius = pillarWidth * 0.6f,
                    center = Offset(rightPillarTop.x, rightPillarTop.y)
                )
            }

            z += pillarSpacing
        }
    }

    private fun drawMathGate(
        drawScope: DrawScope,
        question: MathQuestion,
        gateZ: Float,
        worldType: WorldType,
        project: (Float, Float, Float) -> ProjectedPoint?
    ) {
        val archLeft = project(-2.4f, 0f, gateZ) ?: return
        val archRight = project(2.4f, 0f, gateZ) ?: return
        val archTopLeft = project(-2.4f, 3.4f, gateZ) ?: return
        val archTopRight = project(2.4f, 3.4f, gateZ) ?: return
        val archHeaderBottom = project(-2.4f, 2.3f, gateZ) ?: return

        // 1. Arch Pillars
        val pillarWidth = (0.22f * archLeft.scale * drawScope.size.width * 1.0f).coerceIn(6f, 40f)
        drawScope.drawRect(
            color = Color(0xFF1E293B),
            topLeft = Offset(archTopLeft.x - pillarWidth * 0.5f, archTopLeft.y),
            size = Size(pillarWidth, archLeft.y - archTopLeft.y)
        )
        drawScope.drawRect(
            color = Color(0xFF1E293B),
            topLeft = Offset(archTopRight.x - pillarWidth * 0.5f, archTopRight.y),
            size = Size(pillarWidth, archRight.y - archTopRight.y)
        )

        // 2. Arch Top Banner (Question Display Header)
        val bannerHeight = archHeaderBottom.y - archTopLeft.y
        drawScope.drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF0F172A), Color(0xFF1E1B4B))
            ),
            topLeft = Offset(archTopLeft.x, archTopLeft.y),
            size = Size(archTopRight.x - archTopLeft.x, bannerHeight)
        )
        drawScope.drawRect(
            color = worldType.accentGlow,
            topLeft = Offset(archTopLeft.x, archTopLeft.y),
            size = Size(archTopRight.x - archTopLeft.x, bannerHeight),
            style = Stroke(width = 3f)
        )

        // Question text on Arch
        val archTextSize = (24f * archTopLeft.scale * 35f).coerceIn(14f, 44f)
        textPaint.color = Color.White.toArgb()
        textPaint.textSize = archTextSize
        val archCenter = project(0f, 2.85f, gateZ)
        if (archCenter != null) {
            drawScope.drawContext.canvas.nativeCanvas.drawText(
                question.questionText,
                archCenter.x,
                archCenter.y + archTextSize * 0.35f,
                textPaint
            )
        }

        // 3. 3 Answer Gate Doors (Left: -1.5, Center: 0.0, Right: +1.5)
        val laneXCoords = listOf(-1.5f, 0.0f, 1.5f)
        val laneColors = listOf(
            Color(0xFF3B82F6), // Blue
            Color(0xFF10B981), // Emerald
            Color(0xFFF59E0B)  // Amber
        )

        for (i in 0..2) {
            val laneX = laneXCoords[i]
            val gatePBottom = project(laneX, 0f, gateZ) ?: continue
            val gatePTop = project(laneX, 2.2f, gateZ) ?: continue
            val optionValue = question.options.getOrElse(i) { 0 }

            val boxWidth = (1.15f * gatePBottom.scale * drawScope.size.width * 0.95f).coerceIn(28f, drawScope.size.width * 0.32f)
            val boxHeight = (gatePBottom.y - gatePTop.y) * 0.92f

            // Translucent glowing gate portal
            drawScope.drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        laneColors[i].copy(alpha = 0.85f),
                        laneColors[i].copy(alpha = 0.35f)
                    )
                ),
                topLeft = Offset(gatePTop.x - boxWidth * 0.5f, gatePTop.y),
                size = Size(boxWidth, boxHeight)
            )

            // Neon Border
            drawScope.drawRect(
                color = laneColors[i],
                topLeft = Offset(gatePTop.x - boxWidth * 0.5f, gatePTop.y),
                size = Size(boxWidth, boxHeight),
                style = Stroke(width = 3.5f)
            )

            // Number Billboard (Prominent, High-Contrast)
            val numberTextSize = (32f * gatePTop.scale * 35f).coerceIn(16f, 60f)
            textPaint.color = Color.White.toArgb()
            textPaint.textSize = numberTextSize
            drawScope.drawContext.canvas.nativeCanvas.drawText(
                "$optionValue",
                gatePTop.x,
                gatePTop.y + boxHeight * 0.58f,
                textPaint
            )
        }
    }

    private fun drawCoin(
        drawScope: DrawScope,
        coin: Coin3D,
        runDistance: Float,
        activeDoubleCoins: Boolean,
        project: (Float, Float, Float) -> ProjectedPoint?
    ) {
        val floatOffset = sin((runDistance + coin.z) * 3f) * 0.08f
        val proj = project(coin.x, coin.y + floatOffset, coin.z) ?: return

        val radius = (0.32f * proj.scale * drawScope.size.width * 1.15f).coerceIn(6f, 38f)
        val spinFactor = abs(cos(runDistance * 4f + coin.x * 2f))
        val coinWidth = radius * (0.35f + 0.65f * spinFactor)

        val baseColor = if (activeDoubleCoins) Color(0xFFFBBF24) else Color(0xFFF59E0B)
        val highlightColor = if (activeDoubleCoins) Color(0xFFFEF08A) else Color(0xFFFDE68A)

        // Coin Outer Disc
        drawScope.drawOval(
            brush = Brush.radialGradient(
                colors = listOf(highlightColor, baseColor, Color(0xFFB45309))
            ),
            topLeft = Offset(proj.x - coinWidth, proj.y - radius),
            size = Size(coinWidth * 2f, radius * 2f)
        )

        // Coin Ring & Sparkle
        drawScope.drawOval(
            color = Color(0xFFFEF3C7),
            topLeft = Offset(proj.x - coinWidth * 0.7f, proj.y - radius * 0.7f),
            size = Size(coinWidth * 1.4f, radius * 1.4f),
            style = Stroke(width = 2f)
        )
    }

    private fun drawObstacle(
        drawScope: DrawScope,
        obs: Obstacle3D,
        worldType: WorldType,
        project: (Float, Float, Float) -> ProjectedPoint?
    ) {
        when (obs.type) {
            ObstacleType.HURDLE -> {
                // Hurdle (Must jump over)
                val pBase = project(obs.laneX, 0f, obs.z) ?: return
                val pTop = project(obs.laneX, 0.65f, obs.z) ?: return
                val width = (1.0f * pBase.scale * drawScope.size.width * 1.15f).coerceIn(24f, drawScope.size.width * 0.32f)
                val height = pBase.y - pTop.y

                // Red/White Hazard Stripe Hurdle
                drawScope.drawRect(
                    color = Color(0xFFEF4444),
                    topLeft = Offset(pTop.x - width * 0.5f, pTop.y),
                    size = Size(width, height)
                )
                // Warning Stripes
                drawScope.drawLine(
                    color = Color.White,
                    start = Offset(pTop.x - width * 0.4f, pBase.y),
                    end = Offset(pTop.x + width * 0.4f, pTop.y),
                    strokeWidth = 3f
                )
            }
            ObstacleType.HIGH_BARRIER -> {
                // High Barrier (Must slide under)
                val pBottom = project(obs.laneX, 0.75f, obs.z) ?: return
                val pTop = project(obs.laneX, 2.2f, obs.z) ?: return
                val width = (1.05f * pBottom.scale * drawScope.size.width * 1.15f).coerceIn(26f, drawScope.size.width * 0.33f)
                val height = pBottom.y - pTop.y

                drawScope.drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFFF97316), Color(0xFFEA580C))
                    ),
                    topLeft = Offset(pTop.x - width * 0.5f, pTop.y),
                    size = Size(width, height)
                )
                // Down arrow indicating "SLIDE"
                drawScope.drawLine(
                    color = Color.White,
                    start = Offset(pTop.x, pTop.y + height * 0.2f),
                    end = Offset(pTop.x, pTop.y + height * 0.8f),
                    strokeWidth = 4f
                )
            }
            ObstacleType.ROCK -> {
                // Boulder (Must dodge)
                val pBase = project(obs.laneX, 0f, obs.z) ?: return
                val radius = (0.38f * pBase.scale * drawScope.size.width * 1.15f).coerceIn(14f, drawScope.size.width * 0.15f)

                drawScope.drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF6B7280), Color(0xFF374151), Color(0xFF111827))
                    ),
                    radius = radius,
                    center = Offset(pBase.x, pBase.y - radius)
                )
            }
        }
    }

    private fun drawPowerUpPickup(
        drawScope: DrawScope,
        pickup: PowerUpPickup3D,
        runDistance: Float,
        project: (Float, Float, Float) -> ProjectedPoint?
    ) {
        val floatOffset = sin((runDistance + pickup.z) * 4f) * 0.1f + 0.4f
        val proj = project(pickup.x, floatOffset, pickup.z) ?: return
        val radius = (0.35f * proj.scale * drawScope.size.height * 0.85f).coerceIn(8f, 40f)

        // Glowing Orb Background
        drawScope.drawCircle(
            color = pickup.type.color.copy(alpha = 0.85f),
            radius = radius,
            center = Offset(proj.x, proj.y)
        )
        drawScope.drawCircle(
            color = Color.White,
            radius = radius,
            center = Offset(proj.x, proj.y),
            style = Stroke(width = 3f)
        )

        // Icon Emoji / Symbol
        textPaint.textSize = radius * 1.1f
        drawScope.drawContext.canvas.nativeCanvas.drawText(
            pickup.type.iconSymbol,
            proj.x,
            proj.y + radius * 0.38f,
            textPaint
        )
    }

    private fun drawCharacter(
        drawScope: DrawScope,
        skin: SkinItem,
        laneX: Float,
        playerY: Float,
        playerZ: Float,
        isJumping: Boolean,
        isSliding: Boolean,
        isTripped: Boolean,
        isInvincible: Boolean = false,
        runDistance: Float,
        activeShield: Boolean,
        activeMagnet: Boolean,
        project: (Float, Float, Float) -> ProjectedPoint?
    ) {
        val proj = project(laneX, playerY, playerZ) ?: return

        // Invincibility flicker: skip alternating frames when invincible
        if (isInvincible && (runDistance * 30).toInt() % 2 == 0) {
            return
        }

        val scale = proj.scale * drawScope.size.height * 0.95f
        val charHeight = (1.4f * scale).coerceIn(40f, 220f)
        val charWidth = charHeight * 0.45f

        val feetY = proj.y
        val headY = feetY - charHeight * (if (isSliding) 0.55f else 1.0f)
        val torsoCenterY = (feetY + headY) * 0.5f

        // 1. Ground Shadow
        val shadowProj = project(laneX, 0f, playerZ)
        if (shadowProj != null) {
            val shadowWidth = charWidth * (if (isSliding) 1.5f else 1.1f) * (1.0f - (playerY * 0.3f)).coerceAtLeast(0.4f)
            val shadowHeight = shadowWidth * 0.35f
            drawScope.drawOval(
                color = Color(0x77000000),
                topLeft = Offset(shadowProj.x - shadowWidth * 0.5f, shadowProj.y - shadowHeight * 0.5f),
                size = Size(shadowWidth, shadowHeight)
            )
        }

        // Running gait animation cycle
        val runCycle = runDistance * 12.0f
        val legSwing = if (isJumping || isSliding || isTripped) 0f else sin(runCycle) * 15f
        val armSwing = if (isJumping || isSliding || isTripped) 0f else sin(runCycle + PI.toFloat()) * 18f

        if (isTripped) {
            // Fallen / Stumble state
            drawScope.drawOval(
                color = skin.primaryColor,
                topLeft = Offset(proj.x - charWidth * 0.8f, feetY - charHeight * 0.4f),
                size = Size(charWidth * 1.6f, charHeight * 0.4f)
            )
            drawScope.drawCircle(
                color = skin.accentColor,
                radius = charWidth * 0.35f,
                center = Offset(proj.x + charWidth * 0.5f, feetY - charHeight * 0.3f)
            )
            return
        }

        // 2. Legs
        if (!isSliding) {
            val legWidth = charWidth * 0.28f
            val legLength = charHeight * 0.38f

            // Left Leg
            drawScope.drawLine(
                color = skin.secondaryColor,
                start = Offset(proj.x - charWidth * 0.2f, torsoCenterY + charHeight * 0.1f),
                end = Offset(proj.x - charWidth * 0.2f + legSwing * 0.5f, feetY),
                strokeWidth = legWidth
            )
            // Right Leg
            drawScope.drawLine(
                color = skin.secondaryColor,
                start = Offset(proj.x + charWidth * 0.2f, torsoCenterY + charHeight * 0.1f),
                end = Offset(proj.x + charWidth * 0.2f - legSwing * 0.5f, feetY),
                strokeWidth = legWidth
            )
        }

        // 3. Torso
        val torsoWidth = charWidth * (if (isSliding) 1.2f else 0.85f)
        val torsoHeight = charHeight * (if (isSliding) 0.35f else 0.42f)
        drawScope.drawRoundRect(
            color = skin.primaryColor,
            topLeft = Offset(proj.x - torsoWidth * 0.5f, headY + charHeight * 0.25f),
            size = Size(torsoWidth, torsoHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
        )

        // Backpack / Gear
        drawScope.drawRect(
            color = skin.accentColor,
            topLeft = Offset(proj.x - torsoWidth * 0.35f, headY + charHeight * 0.3f),
            size = Size(torsoWidth * 0.7f, torsoHeight * 0.5f)
        )

        // 4. Arms
        val armWidth = charWidth * 0.22f
        if (!isSliding) {
            // Left Arm
            drawScope.drawLine(
                color = skin.primaryColor,
                start = Offset(proj.x - torsoWidth * 0.45f, headY + charHeight * 0.3f),
                end = Offset(proj.x - torsoWidth * 0.65f - armSwing * 0.4f, headY + charHeight * 0.55f),
                strokeWidth = armWidth
            )
            // Right Arm
            drawScope.drawLine(
                color = skin.primaryColor,
                start = Offset(proj.x + torsoWidth * 0.45f, headY + charHeight * 0.3f),
                end = Offset(proj.x + torsoWidth * 0.65f + armSwing * 0.4f, headY + charHeight * 0.55f),
                strokeWidth = armWidth
            )
        }

        // 5. Head & Helmet / Face
        val headRadius = charWidth * 0.45f
        val headCenterY = headY + headRadius
        drawScope.drawCircle(
            color = skin.helmetColor,
            radius = headRadius,
            center = Offset(proj.x, headCenterY)
        )
        // Visor / Face Mask
        drawScope.drawRoundRect(
            color = skin.accentColor,
            topLeft = Offset(proj.x - headRadius * 0.7f, headCenterY - headRadius * 0.3f),
            size = Size(headRadius * 1.4f, headRadius * 0.6f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
        )

        // 6. Shield Bubble Aura
        if (activeShield) {
            val shieldRadius = charHeight * 0.65f
            drawScope.drawCircle(
                color = Color(0x5538BDF8),
                radius = shieldRadius,
                center = Offset(proj.x, torsoCenterY)
            )
            drawScope.drawCircle(
                color = Color(0xFF38BDF8),
                radius = shieldRadius,
                center = Offset(proj.x, torsoCenterY),
                style = Stroke(width = 4f)
            )
        }

        // 7. Magnet Sparks Aura
        if (activeMagnet) {
            for (i in 0..5) {
                val angle = (runDistance * 8f + i * (PI.toFloat() / 3f))
                val sparkX = proj.x + cos(angle) * (charWidth * 1.2f)
                val sparkY = torsoCenterY + sin(angle) * (charHeight * 0.4f)
                drawScope.drawCircle(
                    color = Color(0xFFEC4899),
                    radius = 5f,
                    center = Offset(sparkX, sparkY)
                )
            }
        }
    }

    private class ProjectedPoint(val x: Float, val y: Float, val scale: Float, val z: Float)
    private class Renderable3D(val z: Float, val drawAction: () -> Unit)
}

data class Coin3D(
    val id: Long,
    var x: Float,
    var y: Float,
    var z: Float,
    var isCollected: Boolean = false
)

data class Obstacle3D(
    val id: Long,
    val laneX: Float,
    val type: ObstacleType,
    var z: Float
)

data class PowerUpPickup3D(
    val id: Long,
    val x: Float,
    var z: Float,
    val type: PowerUpType,
    var isCollected: Boolean = false
)
