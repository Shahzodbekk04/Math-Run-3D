package com.example.game.engine

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

class AudioSynthesizer {

    private val sampleRate = 22050
    private val scope = CoroutineScope(Dispatchers.Default)
    private var musicJob: Job? = null

    var isSoundEnabled: Boolean = true
    var isMusicEnabled: Boolean = true

    fun playCoin() {
        if (!isSoundEnabled) return
        scope.launch {
            playToneSequence(
                listOf(
                    Tone(987.77f, 0.05f, 0.4f), // B5
                    Tone(1318.51f, 0.08f, 0.6f)  // E6
                )
            )
        }
    }

    fun playJump() {
        if (!isSoundEnabled) return
        scope.launch {
            playFrequencySweep(250f, 600f, 0.12f, 0.4f)
        }
    }

    fun playSlide() {
        if (!isSoundEnabled) return
        scope.launch {
            playFrequencySweep(450f, 180f, 0.15f, 0.35f)
        }
    }

    fun playCorrect() {
        if (!isSoundEnabled) return
        scope.launch {
            playToneSequence(
                listOf(
                    Tone(523.25f, 0.07f, 0.5f), // C5
                    Tone(659.25f, 0.07f, 0.55f), // E5
                    Tone(783.99f, 0.07f, 0.6f),  // G5
                    Tone(1046.50f, 0.18f, 0.7f)  // C6
                )
            )
        }
    }

    fun playWrong() {
        if (!isSoundEnabled) return
        scope.launch {
            playToneSequence(
                listOf(
                    Tone(220f, 0.12f, 0.6f),
                    Tone(164.81f, 0.25f, 0.7f)
                )
            )
        }
    }

    fun playWarningBeep() {
        if (!isSoundEnabled) return
        scope.launch {
            playTone(880f, 0.08f, 0.5f)
        }
    }

    fun playCombo(combo: Int) {
        if (!isSoundEnabled) return
        scope.launch {
            val base = 587.33f + (combo * 60f).coerceAtMost(600f)
            playToneSequence(
                listOf(
                    Tone(base, 0.06f, 0.5f),
                    Tone(base * 1.25f, 0.06f, 0.6f),
                    Tone(base * 1.5f, 0.12f, 0.7f)
                )
            )
        }
    }

    fun playGameOver() {
        if (!isSoundEnabled) return
        scope.launch {
            playToneSequence(
                listOf(
                    Tone(440f, 0.15f, 0.6f),
                    Tone(392f, 0.15f, 0.6f),
                    Tone(349.23f, 0.18f, 0.6f),
                    Tone(293.66f, 0.35f, 0.7f)
                )
            )
        }
    }

    fun playLevelUp() {
        if (!isSoundEnabled) return
        scope.launch {
            playToneSequence(
                listOf(
                    Tone(440f, 0.08f, 0.5f),
                    Tone(554.37f, 0.08f, 0.55f),
                    Tone(659.25f, 0.08f, 0.6f),
                    Tone(880f, 0.25f, 0.75f)
                )
            )
        }
    }

    fun startBackgroundMusic() {
        if (musicJob?.isActive == true) return
        musicJob = scope.launch {
            val melody = listOf(
                Tone(329.63f, 0.18f, 0.22f), // E4
                Tone(392.00f, 0.18f, 0.22f), // G4
                Tone(440.00f, 0.18f, 0.25f), // A4
                Tone(493.88f, 0.18f, 0.25f), // B4
                Tone(587.33f, 0.25f, 0.28f), // D5
                Tone(493.88f, 0.18f, 0.22f), // B4
                Tone(440.00f, 0.25f, 0.25f), // A4
                Tone(392.00f, 0.30f, 0.22f)  // G4
            )
            while (isActive) {
                if (isMusicEnabled) {
                    for (note in melody) {
                        if (!isActive || !isMusicEnabled) break
                        playTone(note.freq, note.duration, note.volume)
                        delay((note.duration * 1000).toLong() + 60L)
                    }
                    delay(300L)
                } else {
                    delay(500L)
                }
            }
        }
    }

    fun stopBackgroundMusic() {
        musicJob?.cancel()
        musicJob = null
    }

    private fun playTone(freq: Float, durationSec: Float, volume: Float) {
        val numSamples = (durationSec * sampleRate).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            // Envelope with attack and decay
            val attackSamples = (0.01 * sampleRate).toInt()
            val decaySamples = numSamples - attackSamples
            val env = when {
                i < attackSamples -> (i.toDouble() / attackSamples).toFloat()
                else -> (1.0f - (i - attackSamples).toFloat() / decaySamples).coerceIn(0f, 1f)
            }
            val angle = 2.0 * PI * freq * t
            val sample = (sin(angle) * Short.MAX_VALUE * volume * env).toInt()
            buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        writeToTrack(buffer)
    }

    private fun playToneSequence(tones: List<Tone>) {
        val totalSamples = tones.sumOf { (it.duration * sampleRate).toInt() }
        val buffer = ShortArray(totalSamples)
        var offset = 0

        for (tone in tones) {
            val numSamples = (tone.duration * sampleRate).toInt()
            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val attack = (0.01 * sampleRate).toInt()
                val env = if (i < attack) {
                    (i.toFloat() / attack)
                } else {
                    (1.0f - (i - attack).toFloat() / (numSamples - attack)).coerceIn(0f, 1f)
                }
                val sample = (sin(2.0 * PI * tone.freq * t) * Short.MAX_VALUE * tone.volume * env).toInt()
                buffer[offset + i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
            offset += numSamples
        }
        writeToTrack(buffer)
    }

    private fun playFrequencySweep(startFreq: Float, endFreq: Float, durationSec: Float, volume: Float) {
        val numSamples = (durationSec * sampleRate).toInt()
        val buffer = ShortArray(numSamples)
        var phase = 0.0
        for (i in 0 until numSamples) {
            val progress = i.toFloat() / numSamples
            val currentFreq = startFreq + (endFreq - startFreq) * progress
            phase += 2.0 * PI * currentFreq / sampleRate
            val env = (1.0f - progress)
            val sample = (sin(phase) * Short.MAX_VALUE * volume * env).toInt()
            buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        writeToTrack(buffer)
    }

    private fun writeToTrack(buffer: ShortArray) {
        try {
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()
            scope.launch {
                val durationMs = (buffer.size * 1000L) / sampleRate
                delay(durationMs + 50)
                try {
                    audioTrack.release()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // Audio fallback
        }
    }

    private data class Tone(val freq: Float, val duration: Float, val volume: Float)
}
