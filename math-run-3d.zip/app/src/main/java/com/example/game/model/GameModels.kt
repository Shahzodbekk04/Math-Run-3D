package com.example.game.model

import androidx.compose.ui.graphics.Color

enum class MathMode(
    val id: String,
    val titleUz: String,
    val subtitleUz: String,
    val symbol: String,
    val accentColor: Color
) {
    ADDITION(
        id = "ADDITION",
        titleUz = "+ QO‘SHISH",
        subtitleUz = "Sonlarni tezkor qo‘shish",
        symbol = "+",
        accentColor = Color(0xFF10B981)
    ),
    SUBTRACTION(
        id = "SUBTRACTION",
        titleUz = "− AYIRISH",
        subtitleUz = "Ayirish amallarini yechish",
        symbol = "−",
        accentColor = Color(0xFF0EA5E9)
    ),
    MULTIPLICATION(
        id = "MULTIPLICATION",
        titleUz = "× KO‘PAYTIRISH",
        subtitleUz = "Karrasini topish va hisoblash",
        symbol = "×",
        accentColor = Color(0xFFF59E0B)
    ),
    DIVISION(
        id = "DIVISION",
        titleUz = "÷ BO‘LISH",
        subtitleUz = "Bo‘lish va aralash hisob-kitob",
        symbol = "÷",
        accentColor = Color(0xFF8B5CF6)
    ),
    MIXED(
        id = "MIXED",
        titleUz = "⚡ ARALASH",
        subtitleUz = "Barcha amallar va kombinatsiyalar",
        symbol = "⚡",
        accentColor = Color(0xFFEC4899)
    )
}

enum class DifficultyLevel(val titleUz: String, val baseTimeSec: Float) {
    EASY("Oson", 14.0f),
    MEDIUM("O‘rta", 16.0f),
    HARD("Qiyin", 18.0f),
    EXPERT("Ekspert", 22.0f)
}

data class MathQuestion(
    val id: Int,
    val num1: Int,
    val num2: Int,
    val operation: String,
    val questionText: String,
    val correctAnswer: Int,
    val options: List<Int>, // exactly 3 options for Left (0), Center (1), Right (2)
    val correctIndex: Int,
    val timeLimitSec: Float
)

enum class WorldType(
    val id: String,
    val nameUz: String,
    val descUz: String,
    val skyColorTop: Color,
    val skyColorBottom: Color,
    val groundColor: Color,
    val trackColor: Color,
    val trackLineColor: Color,
    val pillarColor: Color,
    val accentGlow: Color,
    val emoji: String
) {
    JUNGLE(
        id = "JUNGLE",
        nameUz = "Jungle Math Temple",
        descUz = "🌴 O‘rmon va Qadimiy Ibodatxona",
        skyColorTop = Color(0xFF064E3B),
        skyColorBottom = Color(0xFF047857),
        groundColor = Color(0xFF065F46),
        trackColor = Color(0xFF1F2937),
        trackLineColor = Color(0xFF10B981),
        pillarColor = Color(0xFF374151),
        accentGlow = Color(0xFF34D399),
        emoji = "🌴"
    ),
    DESERT(
        id = "DESERT",
        nameUz = "Desert Math Run",
        descUz = "🏜️ Cho‘l va Piramidalar",
        skyColorTop = Color(0xFF78350F),
        skyColorBottom = Color(0xFFD97706),
        groundColor = Color(0xFF92400E),
        trackColor = Color(0xFF451A03),
        trackLineColor = Color(0xFFFBBF24),
        pillarColor = Color(0xFFB45309),
        accentGlow = Color(0xFFFDE68A),
        emoji = "🏜️"
    ),
    ICE(
        id = "ICE",
        nameUz = "Ice Math World",
        descUz = "❄️ Muzli Qorli Dunyo",
        skyColorTop = Color(0xFF0C4A6E),
        skyColorBottom = Color(0xFF0284C7),
        groundColor = Color(0xFF075985),
        trackColor = Color(0xFF0F172A),
        trackLineColor = Color(0xFF38BDF8),
        pillarColor = Color(0xFF0369A1),
        accentGlow = Color(0xFFBAE6FD),
        emoji = "❄️"
    ),
    LAVA(
        id = "LAVA",
        nameUz = "Lava Math World",
        descUz = "🌋 Vulqon va Magma Oqimi",
        skyColorTop = Color(0xFF450A0A),
        skyColorBottom = Color(0xFFDC2626),
        groundColor = Color(0xFF7F1D1D),
        trackColor = Color(0xFF18181B),
        trackLineColor = Color(0xFFEF4444),
        pillarColor = Color(0xFF991B1B),
        accentGlow = Color(0xFFF87171),
        emoji = "🌋"
    ),
    CYBER_CITY(
        id = "CYBER_CITY",
        nameUz = "Future Math City",
        descUz = "🌌 Neon Futuristik Shahar",
        skyColorTop = Color(0xFF1E1B4B),
        skyColorBottom = Color(0xFF4C1D95),
        groundColor = Color(0xFF2E1065),
        trackColor = Color(0xFF09090B),
        trackLineColor = Color(0xFFA855F7),
        pillarColor = Color(0xFF581C87),
        accentGlow = Color(0xFFC084FC),
        emoji = "🌌"
    )
}

data class SkinItem(
    val id: String,
    val nameUz: String,
    val descUz: String,
    val costCoins: Int,
    val requiredLevel: Int,
    val primaryColor: Color,
    val secondaryColor: Color,
    val accentColor: Color,
    val helmetColor: Color,
    val tag: String
) {
    companion object {
        val ALL_SKINS = listOf(
            SkinItem(
                id = "classic",
                nameUz = "Classic Runner",
                descUz = "Klassik qahramon kiyimi",
                costCoins = 0,
                requiredLevel = 1,
                primaryColor = Color(0xFF3B82F6),
                secondaryColor = Color(0xFF1E40AF),
                accentColor = Color(0xFFF59E0B),
                helmetColor = Color(0xFF2563EB),
                tag = "Boshlang‘ich"
            ),
            SkinItem(
                id = "student",
                nameUz = "Student",
                descUz = "Iqtidorli matematik o‘quvchi",
                costCoins = 150,
                requiredLevel = 2,
                primaryColor = Color(0xFF10B981),
                secondaryColor = Color(0xFF047857),
                accentColor = Color(0xFFFBBF24),
                helmetColor = Color(0xFF059669),
                tag = "Talaba"
            ),
            SkinItem(
                id = "ninja",
                nameUz = "Ninja",
                descUz = "Chaqqon va yashirin usta",
                costCoins = 350,
                requiredLevel = 3,
                primaryColor = Color(0xFF18181B),
                secondaryColor = Color(0xFF27272A),
                accentColor = Color(0xFFEF4444),
                helmetColor = Color(0xFF09090B),
                tag = "Chaqqon"
            ),
            SkinItem(
                id = "robot",
                nameUz = "Robot",
                descUz = "Tezkor hisoblovchi kiber korpus",
                costCoins = 600,
                requiredLevel = 4,
                primaryColor = Color(0xFF06B6D4),
                secondaryColor = Color(0xFF0891B2),
                accentColor = Color(0xFF67E8F9),
                helmetColor = Color(0xFF155E75),
                tag = "Kiber"
            ),
            SkinItem(
                id = "space_runner",
                nameUz = "Space Runner",
                descUz = "Koinot sayohatchisi skafandri",
                costCoins = 900,
                requiredLevel = 5,
                primaryColor = Color(0xFFE2E8F0),
                secondaryColor = Color(0xFF94A3B8),
                accentColor = Color(0xFF38BDF8),
                helmetColor = Color(0xFFCBD5E1),
                tag = "Kosmik"
            ),
            SkinItem(
                id = "super_athlete",
                nameUz = "Super Athlete",
                descUz = "Oltin kubokli chempion",
                costCoins = 1300,
                requiredLevel = 6,
                primaryColor = Color(0xFFF59E0B),
                secondaryColor = Color(0xFFD97706),
                accentColor = Color(0xFFFEF08A),
                helmetColor = Color(0xFFB45309),
                tag = "Chempion"
            ),
            SkinItem(
                id = "future_runner",
                nameUz = "Future Runner",
                descUz = "Neon va lazer energiyali korpus",
                costCoins = 1800,
                requiredLevel = 7,
                primaryColor = Color(0xFFA855F7),
                secondaryColor = Color(0xFF7E22CE),
                accentColor = Color(0xFFF472B6),
                helmetColor = Color(0xFF581C87),
                tag = "Futuristik"
            )
        )

        fun getById(id: String): SkinItem =
            ALL_SKINS.find { it.id == id } ?: ALL_SKINS.first()
    }
}

enum class PowerUpType(val titleUz: String, val color: Color, val iconSymbol: String) {
    MAGNET("Tanga Magniti", Color(0xFFEC4899), "🧲"),
    SHIELD("Qalqon Himoyasi", Color(0xFF3B82F6), "🛡️"),
    DOUBLE_COINS("2X Tangalar", Color(0xFFF59E0B), "🪙"),
    SPEED_BOOST("Tezlik Bonusi", Color(0xFF10B981), "⚡"),
    SLOW_MO("Sekinlashtirish", Color(0xFF8B5CF6), "⏳")
}

data class UpgradeItem(
    val id: String,
    val titleUz: String,
    val descUz: String,
    val baseCost: Int,
    val costMultiplier: Int,
    val maxLevel: Int = 5,
    val iconEmoji: String,
    val color: Color
) {
    fun getCost(currentLevel: Int): Int = baseCost + (currentLevel - 1) * costMultiplier

    companion object {
        val ALL_UPGRADES = listOf(
            UpgradeItem(
                id = "MAGNET",
                titleUz = "Coin Magnet",
                descUz = "Yaqin atrofdagi barcha tangalarni avtomatik tortadi",
                baseCost = 100,
                costMultiplier = 150,
                iconEmoji = "🧲",
                color = Color(0xFFEC4899)
            ),
            UpgradeItem(
                id = "SHIELD",
                titleUz = "Shield",
                descUz = "Bitta xato yoki to‘siqdan himoya qiladi",
                baseCost = 150,
                costMultiplier = 200,
                iconEmoji = "🛡️",
                color = Color(0xFF3B82F6)
            ),
            UpgradeItem(
                id = "EXTRA_TIME",
                titleUz = "Extra Time",
                descUz = "Matematik savollarni yechish uchun qo‘shimcha vaqt beradi",
                baseCost = 100,
                costMultiplier = 120,
                iconEmoji = "⏱️",
                color = Color(0xFF10B981)
            ),
            UpgradeItem(
                id = "SPEED_BOOST",
                titleUz = "Speed Boost",
                descUz = "O‘yin tezligini xavfsiz oshiradi va ko‘proq ball beradi",
                baseCost = 120,
                costMultiplier = 140,
                iconEmoji = "⚡",
                color = Color(0xFFF59E0B)
            )
        )
    }
}

enum class GameEvent(val titleUz: String, val descUz: String, val color: Color) {
    DOUBLE_COINS("DOUBLE COINS!", "Barcha tangalar 2 barobar ko‘payadi!", Color(0xFFFBBF24)),
    SPEED_EVENT("SPEED EVENT!", "Yugurish tezligi oshdi, ko‘proq XP!", Color(0xFF38BDF8)),
    MATH_RUSH("MATH RUSH!", "Savollar tezroq keladi!", Color(0xFFA855F7)),
    COIN_STORM("COIN STORM!", "Yo‘lda tangalar yomg‘iri!", Color(0xFF34D399)),
    PERFECT_RUN("PERFECT RUN!", "Har bir to‘g‘ri javobga +50 bonus!", Color(0xFFF43F5E))
}

enum class Lane(val index: Int, val xOffset: Float) {
    LEFT(0, -1.5f),
    CENTER(1, 0.0f),
    RIGHT(2, 1.5f);

    companion object {
        fun fromIndex(index: Int): Lane = when (index) {
            0 -> LEFT
            2 -> RIGHT
            else -> CENTER
        }
    }
}

enum class ObstacleType(val heightType: HeightType) {
    HURDLE(HeightType.LOW), // jump
    HIGH_BARRIER(HeightType.HIGH), // slide
    ROCK(HeightType.FULL); // dodge lane

    enum class HeightType { LOW, HIGH, FULL }
}

data class ActivePowerUp(
    val type: PowerUpType,
    var remainingTimeSec: Float,
    val totalDurationSec: Float
)

data class Particle3D(
    var x: Float,
    var y: Float,
    var z: Float,
    var vx: Float,
    var vy: Float,
    var vz: Float,
    val color: Color,
    var size: Float,
    var life: Float,
    val maxLife: Float
)

data class FloatingTextEffect(
    val text: String,
    var x: Float,
    var y: Float,
    var z: Float,
    val color: Color,
    var alpha: Float = 1.0f,
    var scale: Float = 1.0f,
    var lifetimeSec: Float = 1.2f
)
