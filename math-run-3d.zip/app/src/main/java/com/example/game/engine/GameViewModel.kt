package com.example.game.engine

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.MathRunDatabase
import com.example.data.model.PlayerProfileEntity
import com.example.data.model.RunRecordEntity
import com.example.data.repository.GameRepository
import com.example.game.model.ActivePowerUp
import com.example.game.model.FloatingTextEffect
import com.example.game.model.GameEvent
import com.example.game.model.Lane
import com.example.game.model.MathMode
import com.example.game.model.MathQuestion
import com.example.game.model.ObstacleType
import com.example.game.model.Particle3D
import com.example.game.model.PowerUpType
import com.example.game.model.SkinItem
import com.example.game.model.WorldType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

enum class AppScreen {
    MENU, GAME, GAME_OVER, SKINS, UPGRADES, LEADERBOARD, SETTINGS
}

enum class RunState {
    READY, RUNNING, QUESTION_ACTIVE, PASSED_GATE, TRIPPED, GAME_OVER
}

data class GameUiState(
    val currentScreen: AppScreen = AppScreen.MENU,
    val selectedMode: MathMode = MathMode.ADDITION,
    val currentWorld: WorldType = WorldType.JUNGLE,
    val selectedSkin: SkinItem = SkinItem.ALL_SKINS.first(),
    val unlockedSkins: Set<String> = setOf("classic"),
    val runState: RunState = RunState.READY,
    val isPaused: Boolean = false,
    val score: Int = 0,
    val coinsEarned: Int = 0,
    val distanceMeters: Int = 0,
    val correctAnswersCount: Int = 0,
    val wrongAnswersCount: Int = 0,
    val currentCombo: Int = 0,
    val bestCombo: Int = 0,
    val lives: Int = 3,
    val maxLives: Int = 3,
    val questionNumber: Int = 1,
    val totalQuestionsTarget: Int = 15,
    val activeQuestion: MathQuestion? = null,
    val questionTimeRemainingSec: Float = 14f,
    val questionTotalTimeSec: Float = 14f,
    val activeEvent: GameEvent? = null,
    val activeEventTimeRemainingSec: Float = 0f,
    val activePowerUps: List<ActivePowerUp> = emptyList(),
    val showNewRecordBanner: Boolean = false,
    val showTutorial: Boolean = false,
    val feedbackBannerText: String? = null,
    val feedbackBannerColor: Color = Color.Green
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository
    val audioSynthesizer = AudioSynthesizer()
    private val vibrator: Vibrator?

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    val playerProfile: StateFlow<PlayerProfileEntity?>
    val topRecords: StateFlow<List<RunRecordEntity>>
    val totalRunsCount: StateFlow<Int>
    val highestScore: StateFlow<Int?>

    // Gameplay 3D State
    var playerLaneIndex = 1 // 0=LEFT, 1=CENTER, 2=RIGHT
    var currentLaneX = 0.0f
    var targetLaneX = 0.0f
    var playerY = 0.0f
    var jumpVelocity = 0.0f
    var isJumping = false
    var isSliding = false
    var slideTimer = 0.0f
    var isTripped = false
    var tripTimer = 0.0f
    var invincibleTimer = 0.0f

    var runDistance = 0.0f
    var baseSpeed = 9.0f // units per second
    var currentSpeed = 9.0f
    var gateZ: Float? = null

    val coinsList = mutableListOf<Coin3D>()
    val obstaclesList = mutableListOf<Obstacle3D>()
    val powerUpPickupsList = mutableListOf<PowerUpPickup3D>()
    val particlesList = mutableListOf<Particle3D>()
    val floatingTextsList = mutableListOf<FloatingTextEffect>()

    var screenShakeOffset = Offset.Zero
    var screenShakeTimer = 0.0f

    private var uiUpdateTimer = 0.0f
    private var accumulatedDistanceScore = 0.0f

    private var gameLoopJob: Job? = null
    private var objectIdCounter = 0L

    init {
        val db = MathRunDatabase.getDatabase(application)
        repository = GameRepository(db.mathRunDao())

        playerProfile = repository.playerProfile.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            null
        )
        topRecords = repository.topRecords.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            emptyList()
        )
        totalRunsCount = repository.totalRunsCount.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            0
        )
        highestScore = repository.highestScore.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            null
        )

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        viewModelScope.launch {
            val profile = repository.ensureProfile()
            audioSynthesizer.isSoundEnabled = profile.soundEnabled
            audioSynthesizer.isMusicEnabled = profile.musicEnabled
            val unlocked = GameRepository.parseUnlockedSkins(profile.unlockedSkinIdsJson)
            val skin = SkinItem.getById(profile.currentSkinId)
            _uiState.value = _uiState.value.copy(
                unlockedSkins = unlocked,
                selectedSkin = skin
            )
            if (profile.musicEnabled) {
                audioSynthesizer.startBackgroundMusic()
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        if (screen == AppScreen.GAME) {
            startRun(_uiState.value.selectedMode)
        } else {
            if (_uiState.value.currentScreen == AppScreen.GAME) {
                stopGameLoop()
            }
            _uiState.value = _uiState.value.copy(currentScreen = screen, isPaused = false)
        }
    }

    fun selectMode(mode: MathMode) {
        _uiState.value = _uiState.value.copy(selectedMode = mode)
        startRun(mode)
    }

    fun ensureGameRunning() {
        if (_uiState.value.currentScreen == AppScreen.GAME &&
            _uiState.value.runState == RunState.RUNNING &&
            !_uiState.value.isPaused
        ) {
            if (gameLoopJob == null || gameLoopJob?.isActive != true) {
                startGameLoop()
            }
        }
    }

    fun selectWorld(world: WorldType) {
        _uiState.value = _uiState.value.copy(currentWorld = world)
    }

    fun startRun(mode: MathMode = _uiState.value.selectedMode) {
        val profile = playerProfile.value ?: PlayerProfileEntity()
        val showTutorial = false

        // Pick world dynamically based on mode or random
        val randomWorld = when (mode) {
            MathMode.ADDITION -> WorldType.JUNGLE
            MathMode.SUBTRACTION -> WorldType.DESERT
            MathMode.MULTIPLICATION -> WorldType.ICE
            MathMode.DIVISION -> WorldType.CYBER_CITY
            MathMode.MIXED -> WorldType.LAVA
        }

        // Reset runner physics and state
        playerLaneIndex = 1
        currentLaneX = 0f
        targetLaneX = 0f
        playerY = 0f
        jumpVelocity = 0f
        isJumping = false
        isSliding = false
        slideTimer = 0f
        isTripped = false
        tripTimer = 0f
        invincibleTimer = 0f
        runDistance = 0f
        baseSpeed = 8.5f + (profile.speedBoostLvl - 1) * 0.4f
        currentSpeed = baseSpeed
        gateZ = null

        coinsList.clear()
        obstaclesList.clear()
        powerUpPickupsList.clear()
        particlesList.clear()
        floatingTextsList.clear()

        // Generate first batch of coins and first question
        val extraTime = (profile.extraTimeLvl - 1) * 2.0f
        val firstQuestion = MathQuestionGenerator.generateQuestion(1, mode, extraTime)
        gateZ = 55.0f

        // Initial safe runway: coins only up to 25m, safe buffer before gate
        generateTrackObjects(startZ = 20.0f, endZ = 50.0f)

        _uiState.value = GameUiState(
            currentScreen = AppScreen.GAME,
            selectedMode = mode,
            currentWorld = randomWorld,
            selectedSkin = SkinItem.getById(profile.currentSkinId),
            unlockedSkins = GameRepository.parseUnlockedSkins(profile.unlockedSkinIdsJson),
            runState = RunState.RUNNING,
            isPaused = false,
            score = 0,
            coinsEarned = 0,
            distanceMeters = 0,
            correctAnswersCount = 0,
            wrongAnswersCount = 0,
            currentCombo = 0,
            bestCombo = 0,
            lives = 3,
            maxLives = 3,
            questionNumber = 1,
            totalQuestionsTarget = 15,
            activeQuestion = firstQuestion,
            questionTimeRemainingSec = firstQuestion.timeLimitSec,
            questionTotalTimeSec = firstQuestion.timeLimitSec,
            showTutorial = showTutorial
        )

        startGameLoop()
    }

    private fun startGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            var lastTime = System.nanoTime()
            while (isActive && _uiState.value.currentScreen == AppScreen.GAME) {
                val now = System.nanoTime()
                val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastTime = now

                if (!_uiState.value.isPaused && !_uiState.value.showTutorial && _uiState.value.runState != RunState.GAME_OVER) {
                    updateGame(dt)
                }
                delay(16L) // Target ~60 FPS
            }
        }
    }

    fun stopGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = null
    }

    fun togglePause() {
        val newPaused = !_uiState.value.isPaused
        _uiState.value = _uiState.value.copy(isPaused = newPaused)
    }

    fun resumeGame() {
        _uiState.value = _uiState.value.copy(isPaused = false)
    }

    fun restartCurrentGame() {
        startRun(_uiState.value.selectedMode)
    }

    fun quitToMainMenu() {
        stopGameLoop()
        _uiState.value = _uiState.value.copy(
            currentScreen = AppScreen.MENU,
            isPaused = false
        )
    }

    fun completeTutorial() {
        viewModelScope.launch {
            repository.markTutorialCompleted()
            _uiState.value = _uiState.value.copy(showTutorial = false)
        }
    }

    // Touch / Swipe & Arrow Button Controls
    fun onSwipeLeft() {
        if (_uiState.value.runState == RunState.RUNNING && !_uiState.value.isPaused) {
            isTripped = false
            tripTimer = 0f
            if (playerLaneIndex > 0) {
                playerLaneIndex--
                targetLaneX = Lane.fromIndex(playerLaneIndex).xOffset
                vibrate(20)
            }
        }
    }

    fun onSwipeRight() {
        if (_uiState.value.runState == RunState.RUNNING && !_uiState.value.isPaused) {
            isTripped = false
            tripTimer = 0f
            if (playerLaneIndex < 2) {
                playerLaneIndex++
                targetLaneX = Lane.fromIndex(playerLaneIndex).xOffset
                vibrate(20)
            }
        }
    }

    fun setLane(laneIndex: Int) {
        if (_uiState.value.runState == RunState.RUNNING && !_uiState.value.isPaused) {
            val clamped = laneIndex.coerceIn(0, 2)
            if (clamped != playerLaneIndex) {
                playerLaneIndex = clamped
                targetLaneX = Lane.fromIndex(playerLaneIndex).xOffset
                vibrate(20)
            }
        }
    }

    fun onSwipeUp() {
        if (_uiState.value.runState == RunState.RUNNING && !_uiState.value.isPaused) {
            isTripped = false
            tripTimer = 0f
            isSliding = false
            slideTimer = 0f
            if (!isJumping) {
                isJumping = true
                jumpVelocity = 5.2f
                audioSynthesizer.playJump()
                vibrate(25)
            }
        }
    }

    fun onSwipeDown() {
        if (_uiState.value.runState == RunState.RUNNING && !_uiState.value.isPaused) {
            isTripped = false
            tripTimer = 0f
            if (isJumping) {
                isJumping = false
                jumpVelocity = 0f
                playerY = 0f
            }
            if (!isSliding) {
                isSliding = true
                slideTimer = 0.8f
                audioSynthesizer.playSlide()
                vibrate(25)
            }
        }
    }

    private fun updateGame(dt: Float) {
        val state = _uiState.value
        val profile = playerProfile.value ?: PlayerProfileEntity()

        // Update timers
        if (invincibleTimer > 0f) {
            invincibleTimer -= dt
        }
        if (tripTimer > 0f) {
            tripTimer -= dt
            if (tripTimer <= 0f) {
                isTripped = false
            }
        }

        // 1. Advance distance and speed
        runDistance += currentSpeed * dt
        val distanceMeters = runDistance.toInt()

        // 2. Smooth lane movement (Ultra snappy and responsive)
        val laneLerpSpeed = 26.0f * profile.swipeSensitivity
        currentLaneX += (targetLaneX - currentLaneX) * (laneLerpSpeed * dt).coerceAtMost(1f)

        // 3. Jump physics
        if (isJumping) {
            playerY += jumpVelocity * dt
            jumpVelocity -= 14.0f * dt // gravity
            if (playerY <= 0f) {
                playerY = 0f
                isJumping = false
                jumpVelocity = 0f
            }
        }

        // 4. Slide timer
        if (isSliding) {
            slideTimer -= dt
            if (slideTimer <= 0f) {
                isSliding = false
            }
        }

        // 5. Screen shake decay
        if (screenShakeTimer > 0f) {
            screenShakeTimer -= dt
            screenShakeOffset = Offset(
                Random.nextFloat() * 14f - 7f,
                Random.nextFloat() * 14f - 7f
            )
            if (screenShakeTimer <= 0f) {
                screenShakeOffset = Offset.Zero
            }
        }

        // 6. Active Event timer
        var activeEvent = state.activeEvent
        var activeEventTime = state.activeEventTimeRemainingSec
        if (activeEvent != null) {
            activeEventTime -= dt
            if (activeEventTime <= 0f) {
                activeEvent = null
            }
        } else if (Random.nextFloat() < 0.0008f) { // Random event chance
            activeEvent = GameEvent.values().random()
            activeEventTime = 12.0f
            spawnFloatingText(activeEvent.titleUz, 0f, 2.5f, 5f, activeEvent.color)
        }

        // 7. Active Power-ups timers
        val updatedPowerUps = state.activePowerUps.mapNotNull { p ->
            val remaining = p.remainingTimeSec - dt
            if (remaining > 0f) p.copy(remainingTimeSec = remaining) else null
        }

        val hasMagnet = updatedPowerUps.any { it.type == PowerUpType.MAGNET }
        val hasShield = updatedPowerUps.any { it.type == PowerUpType.SHIELD }
        val hasDoubleCoins = updatedPowerUps.any { it.type == PowerUpType.DOUBLE_COINS } || activeEvent == GameEvent.DOUBLE_COINS
        val hasSpeedBoost = updatedPowerUps.any { it.type == PowerUpType.SPEED_BOOST } || activeEvent == GameEvent.SPEED_EVENT

        currentSpeed = baseSpeed * (if (hasSpeedBoost) 1.35f else 1.0f)

        // 8. Question Countdown Timer
        var questionTime = state.questionTimeRemainingSec
        val currentQ = state.activeQuestion
        if (currentQ != null && gateZ != null) {
            questionTime -= dt
            // Warning beep at 3, 2, 1 sec
            if (questionTime in 0.9f..3.1f && (questionTime % 1.0f) < 0.05f) {
                audioSynthesizer.playWarningBeep()
            }

            if (questionTime <= 0f) {
                // TIME OUT!
                handleWrongAnswer("VAQT TUGADI!")
                return
            }
        }

        // 9. Move Gate closer
        var currentGateZ = gateZ
        if (currentGateZ != null && currentQ != null) {
            currentGateZ -= currentSpeed * dt
            gateZ = currentGateZ

            // Check if player reaches the gate (Player is at Z = 2.4f)
            if (currentGateZ <= 2.8f) {
                val chosenLaneIndex = playerLaneIndex
                val isCorrect = chosenLaneIndex == currentQ.correctIndex

                if (isCorrect) {
                    handleCorrectAnswer(currentQ)
                } else {
                    if (hasShield) {
                        // Shield absorbs mistake
                        spawnFloatingText("🛡️ QALQON SAQLADI!", 0f, 2.5f, 4f, Color(0xFF38BDF8))
                        audioSynthesizer.playJump()
                        val powerUpsWithoutShield = updatedPowerUps.filterNot { it.type == PowerUpType.SHIELD }
                        _uiState.value = _uiState.value.copy(activePowerUps = powerUpsWithoutShield)
                        setupNextQuestion()
                    } else {
                        handleWrongAnswer("NOTO‘G‘RI JAVOB!")
                        return
                    }
                }
            }
        }

        // 10. Update Coins
        val playerZ = 2.4f
        for (coin in coinsList) {
            coin.z -= currentSpeed * dt

            // Magnet pull effect
            if (hasMagnet && !coin.isCollected && coin.z in 1.0f..15.0f) {
                coin.z -= 4.0f * dt
                val dx = currentLaneX - coin.x
                coin.x = coin.x + dx * 6.0f * dt
            }

            // Coin collision (wide lane tolerance)
            if (!coin.isCollected && abs(coin.z - playerZ) < 0.9f && abs(coin.x - currentLaneX) < 0.85f) {
                coin.isCollected = true
                val coinVal = if (hasDoubleCoins) 2 else 1
                val newCoins = _uiState.value.coinsEarned + coinVal
                val newScore = _uiState.value.score + coinVal * 10
                _uiState.value = _uiState.value.copy(coinsEarned = newCoins, score = newScore)
                audioSynthesizer.playCoin()
                spawnParticles(coin.x, coin.y, coin.z, Color(0xFFFBBF24), 8)
            }
        }
        coinsList.removeAll { it.z < 0.5f || it.isCollected }

        // 11. Update Obstacles (wide lane tolerance)
        for (obs in obstaclesList) {
            obs.z -= currentSpeed * dt
            if (abs(obs.z - playerZ) < 0.7f && abs(obs.laneX - currentLaneX) < 0.80f) {
                var collided = false
                when (obs.type) {
                    ObstacleType.HURDLE -> if (!isJumping || playerY < 0.4f) collided = true
                    ObstacleType.HIGH_BARRIER -> if (!isSliding) collided = true
                    ObstacleType.ROCK -> collided = true
                }
                if (collided) {
                    if (hasShield) {
                        spawnFloatingText("🛡️ QALQON SAQLADI!", 0f, 2.5f, 4f, Color(0xFF38BDF8))
                        val powerUpsWithoutShield = updatedPowerUps.filterNot { it.type == PowerUpType.SHIELD }
                        _uiState.value = _uiState.value.copy(activePowerUps = powerUpsWithoutShield)
                        obs.z = -10f // Clear obstacle
                    } else if (invincibleTimer <= 0f) {
                        handleCollision(obs)
                        return
                    }
                }
            }
        }
        obstaclesList.removeAll { it.z < 0.5f }

        // 12. Update PowerUp Pickups (wide lane tolerance)
        for (pickup in powerUpPickupsList) {
            pickup.z -= currentSpeed * dt
            if (!pickup.isCollected && abs(pickup.z - playerZ) < 0.9f && abs(pickup.x - currentLaneX) < 0.85f) {
                pickup.isCollected = true
                val duration = when (pickup.type) {
                    PowerUpType.MAGNET -> 8.0f + (profile.magnetLvl - 1) * 2.0f
                    PowerUpType.SHIELD -> 15.0f + (profile.shieldLvl - 1) * 3.0f
                    PowerUpType.DOUBLE_COINS -> 10.0f
                    PowerUpType.SPEED_BOOST -> 8.0f
                    PowerUpType.SLOW_MO -> 6.0f
                }
                val newActivePowerUps = updatedPowerUps.filterNot { it.type == pickup.type } +
                        ActivePowerUp(pickup.type, duration, duration)
                _uiState.value = _uiState.value.copy(activePowerUps = newActivePowerUps)
                audioSynthesizer.playCorrect()
                spawnFloatingText(pickup.type.titleUz, pickup.x, 2.2f, playerZ, pickup.type.color)
            }
        }
        powerUpPickupsList.removeAll { it.z < 0.5f || it.isCollected }

        // 13. Update Particles
        for (p in particlesList) {
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.z += p.vz * dt
            p.life -= dt
        }
        particlesList.removeAll { it.life <= 0f }

        // 14. Update Floating Texts
        for (ft in floatingTextsList) {
            ft.y += 0.8f * dt
            ft.lifetimeSec -= dt
            ft.alpha = (ft.lifetimeSec / 1.2f).coerceIn(0f, 1f)
            ft.scale += 0.2f * dt
        }
        floatingTextsList.removeAll { ft -> ft.lifetimeSec <= 0f }

        // Generate more track objects ahead
        val furthestZ = (coinsList.maxOfOrNull { it.z } ?: 0f)
            .coerceAtLeast(obstaclesList.maxOfOrNull { it.z } ?: 0f)
        if (furthestZ < 45.0f && (gateZ == null || gateZ!! < 20f || gateZ!! > 55f)) {
            generateTrackObjects(furthestZ + 8f, furthestZ + 35f)
        }

        // Throttle UI state emissions (every ~80ms) to prevent UI thread recomposition lag
        accumulatedDistanceScore += currentSpeed * dt * 2.5f
        uiUpdateTimer += dt
        if (uiUpdateTimer >= 0.08f) {
            uiUpdateTimer = 0.0f
            val addScore = accumulatedDistanceScore.toInt()
            accumulatedDistanceScore -= addScore
            _uiState.value = state.copy(
                score = state.score + addScore,
                distanceMeters = distanceMeters,
                questionTimeRemainingSec = questionTime,
                activeEvent = activeEvent,
                activeEventTimeRemainingSec = activeEventTime,
                activePowerUps = updatedPowerUps
            )
        }
    }

    private fun handleCorrectAnswer(question: MathQuestion) {
        val state = _uiState.value
        val combo = state.currentCombo + 1
        val bestCombo = combo.coerceAtLeast(state.bestCombo)
        val comboMultiplier = when {
            combo >= 10 -> 5
            combo >= 5 -> 3
            combo >= 3 -> 2
            else -> 1
        }
        val pointsEarned = (100 * comboMultiplier) + (state.questionTimeRemainingSec * 10).toInt()
        val bonusCoins = (comboMultiplier)

        val newScore = state.score + pointsEarned
        val newCoins = state.coinsEarned + bonusCoins
        val newCorrect = state.correctAnswersCount + 1

        audioSynthesizer.playCorrect()
        if (combo >= 3) {
            audioSynthesizer.playCombo(combo)
        }
        vibrate(35)

        // Spawn visual confetti & combo burst
        spawnParticles(currentLaneX, 1.5f, 3.0f, Color(0xFF10B981), 25)
        spawnFloatingText("✅ TO‘G‘RI! +$pointsEarned", currentLaneX, 2.8f, 3.0f, Color(0xFF10B981))
        if (combo >= 3) {
            spawnFloatingText("🔥 $combo COMBO! (x$comboMultiplier)", 0f, 3.4f, 3.0f, Color(0xFFF59E0B))
        }

        _uiState.value = state.copy(
            score = newScore,
            coinsEarned = newCoins,
            correctAnswersCount = newCorrect,
            currentCombo = combo,
            bestCombo = bestCombo,
            feedbackBannerText = "✅ TO‘G‘RI JAVOB!",
            feedbackBannerColor = Color(0xFF10B981)
        )

        // Check if finished 15 questions run target -> Bonus!
        if (state.questionNumber >= state.totalQuestionsTarget && (state.questionNumber % state.totalQuestionsTarget == 0)) {
            val finishBonusCoins = 100
            val totalFinishCoins = newCoins + finishBonusCoins
            _uiState.value = _uiState.value.copy(
                coinsEarned = totalFinishCoins,
                score = newScore + 1000
            )
            audioSynthesizer.playLevelUp()
            spawnFloatingText("🏆 BOSQICH TUGADI! +100 COINS!", 0f, 3.0f, 3.0f, Color(0xFFFBBF24))
        }

        setupNextQuestion()
    }

    private fun setupNextQuestion() {
        val nextQNum = _uiState.value.questionNumber + 1
        val profile = playerProfile.value ?: PlayerProfileEntity()
        val extraTime = (profile.extraTimeLvl - 1) * 2.0f
        val nextQuestion = MathQuestionGenerator.generateQuestion(
            questionNumber = nextQNum,
            mode = _uiState.value.selectedMode,
            extraTimeBonusSec = extraTime
        )

        // Gradual speed acceleration capped at 15.0f
        baseSpeed = (baseSpeed + 0.2f).coerceAtMost(15.0f)
        gateZ = 55.0f
        _uiState.value = _uiState.value.copy(
            questionNumber = nextQNum,
            activeQuestion = nextQuestion,
            questionTimeRemainingSec = nextQuestion.timeLimitSec,
            questionTotalTimeSec = nextQuestion.timeLimitSec
        )

        // Clear feedback banner after 1.5s
        viewModelScope.launch {
            delay(1500)
            _uiState.value = _uiState.value.copy(feedbackBannerText = null)
        }
    }

    private fun handleWrongAnswer(reason: String) {
        val state = _uiState.value
        val newWrong = state.wrongAnswersCount + 1
        val currentLives = state.lives

        audioSynthesizer.playWrong()
        vibrate(80)
        screenShakeTimer = 0.35f
        spawnParticles(currentLaneX, 1.0f, 3.0f, Color(0xFFEF4444), 30)

        if (currentLives > 1) {
            val newLives = currentLives - 1
            isTripped = true
            tripTimer = 0.4f
            invincibleTimer = 2.0f

            spawnFloatingText("💔 -1 JON! ($newLives qoldi)", currentLaneX, 2.5f, 3.0f, Color(0xFFEF4444))
            _uiState.value = state.copy(
                lives = newLives,
                wrongAnswersCount = newWrong,
                currentCombo = 0,
                feedbackBannerText = "❌ $reason ($newLives ta jon qoldi)",
                feedbackBannerColor = Color(0xFFEF4444)
            )
            setupNextQuestion()
        } else {
            // Last life lost -> Game Over
            isTripped = true
            spawnFloatingText("❌ $reason", currentLaneX, 2.5f, 3.0f, Color(0xFFEF4444))
            _uiState.value = state.copy(
                lives = 0,
                wrongAnswersCount = newWrong,
                currentCombo = 0,
                feedbackBannerText = "❌ $reason",
                feedbackBannerColor = Color(0xFFEF4444)
            )
            viewModelScope.launch {
                delay(700)
                finishRun()
            }
        }
    }

    private fun handleCollision(obs: Obstacle3D) {
        val state = _uiState.value
        val currentLives = state.lives

        audioSynthesizer.playWrong()
        vibrate(90)
        screenShakeTimer = 0.4f
        spawnParticles(currentLaneX, 1.0f, 3.0f, Color(0xFFEA580C), 30)

        // Clear obstacle so it doesn't collide again
        obs.z = -10f

        if (currentLives > 1) {
            val newLives = currentLives - 1
            isTripped = true
            tripTimer = 0.5f
            invincibleTimer = 2.0f

            spawnFloatingText("💔 -1 JON! ($newLives qoldi)", currentLaneX, 2.5f, 3.0f, Color(0xFFEF4444))
            _uiState.value = state.copy(
                lives = newLives,
                currentCombo = 0,
                feedbackBannerText = "💥 TO‘SIQ! ($newLives ta jon qoldi)",
                feedbackBannerColor = Color(0xFFEF4444)
            )
            viewModelScope.launch {
                delay(1200)
                _uiState.value = _uiState.value.copy(feedbackBannerText = null)
            }
        } else {
            // Last life lost -> Game Over
            isTripped = true
            spawnFloatingText("💥 TO‘SIQQA URILDI!", currentLaneX, 2.5f, 3.0f, Color(0xFFEF4444))
            _uiState.value = state.copy(
                lives = 0,
                currentCombo = 0,
                feedbackBannerText = "💥 O‘YIN TUGADI!",
                feedbackBannerColor = Color(0xFFEF4444)
            )
            viewModelScope.launch {
                delay(700)
                finishRun()
            }
        }
    }

    private fun finishRun() {
        stopGameLoop()
        val state = _uiState.value
        val prevHigh = highestScore.value ?: 0
        val isNewRecord = state.score > prevHigh && state.score > 0

        audioSynthesizer.playGameOver()

        viewModelScope.launch {
            repository.saveRunResult(
                score = state.score,
                coinsEarned = state.coinsEarned,
                correctCount = state.correctAnswersCount,
                wrongCount = state.wrongAnswersCount,
                bestCombo = state.bestCombo,
                distanceMeters = state.distanceMeters,
                mode = state.selectedMode.id,
                world = state.currentWorld.id
            )
        }

        _uiState.value = state.copy(
            runState = RunState.GAME_OVER,
            currentScreen = AppScreen.GAME_OVER,
            showNewRecordBanner = isNewRecord
        )
    }

    private fun generateTrackObjects(startZ: Float, endZ: Float) {
        var z = startZ.coerceAtLeast(18.0f) // Never spawn closer than 18m
        while (z < endZ) {
            val currentGZ = gateZ
            // If near math gate, leave comfortable buffer around gate
            if (currentGZ != null && z in (currentGZ - 10f)..(currentGZ + 6f)) {
                coinsList.add(Coin3D(++objectIdCounter, 0f, 0.4f, z))
                z += 4f
                continue
            }

            val laneIndex = Random.nextInt(3)
            val laneX = Lane.fromIndex(laneIndex).xOffset

            val pattern = Random.nextInt(5)

            when (pattern) {
                0 -> {
                    // Straight Coin Trail (3-6 coins)
                    val count = Random.nextInt(3, 7)
                    for (i in 0 until count) {
                        coinsList.add(Coin3D(++objectIdCounter, laneX, 0.4f, z + i * 2.2f))
                    }
                    z += count * 2.2f + 3f
                }
                1 -> {
                    // Rainbow Arc of Coins
                    coinsList.add(Coin3D(++objectIdCounter, laneX, 0.4f, z + 1f))
                    coinsList.add(Coin3D(++objectIdCounter, laneX, 0.9f, z + 3f))
                    coinsList.add(Coin3D(++objectIdCounter, laneX, 1.3f, z + 5f))
                    coinsList.add(Coin3D(++objectIdCounter, laneX, 0.9f, z + 7f))
                    coinsList.add(Coin3D(++objectIdCounter, laneX, 0.4f, z + 9f))
                    z += 12f
                }
                2 -> {
                    // Zig-zag Coins across lanes
                    val nextLaneIndex = (laneIndex + 1) % 3
                    val nextLaneX = Lane.fromIndex(nextLaneIndex).xOffset
                    coinsList.add(Coin3D(++objectIdCounter, laneX, 0.4f, z + 1.5f))
                    coinsList.add(Coin3D(++objectIdCounter, laneX, 0.4f, z + 3.0f))
                    coinsList.add(Coin3D(++objectIdCounter, nextLaneX, 0.4f, z + 5.5f))
                    coinsList.add(Coin3D(++objectIdCounter, nextLaneX, 0.4f, z + 7.0f))
                    z += 10f
                }
                3 -> {
                    // Power-up pickup crystal
                    val powerUpType = PowerUpType.values().random()
                    powerUpPickupsList.add(PowerUpPickup3D(++objectIdCounter, laneX, z + 2f, powerUpType))
                    coinsList.add(Coin3D(++objectIdCounter, laneX, 0.4f, z + 4.5f))
                    z += 8f
                }
                else -> {
                    // Double lane parallel coins
                    val otherLaneIndex = if (laneIndex == 1) 0 else 1
                    val otherLaneX = Lane.fromIndex(otherLaneIndex).xOffset
                    for (i in 0 until 3) {
                        coinsList.add(Coin3D(++objectIdCounter, laneX, 0.4f, z + i * 2.2f))
                        coinsList.add(Coin3D(++objectIdCounter, otherLaneX, 0.4f, z + i * 2.2f))
                    }
                    z += 9f
                }
            }
        }
    }

    private fun spawnParticles(x: Float, y: Float, z: Float, color: Color, count: Int) {
        for (i in 0 until count) {
            particlesList.add(
                Particle3D(
                    x = x,
                    y = y,
                    z = z,
                    vx = (Random.nextFloat() - 0.5f) * 4f,
                    vy = Random.nextFloat() * 4f + 1f,
                    vz = (Random.nextFloat() - 0.5f) * 4f,
                    color = color,
                    size = Random.nextFloat() * 4f + 3f,
                    life = 0.6f + Random.nextFloat() * 0.4f,
                    maxLife = 1.0f
                )
            )
        }
    }

    private fun spawnFloatingText(text: String, x: Float, y: Float, z: Float, color: Color) {
        floatingTextsList.add(
            FloatingTextEffect(
                text = text,
                x = x,
                y = y,
                z = z,
                color = color
            )
        )
    }

    fun buySkin(skin: SkinItem) {
        viewModelScope.launch {
            val success = repository.unlockSkin(skin.id, skin.costCoins)
            if (success) {
                audioSynthesizer.playLevelUp()
                vibrate(40)
                val profile = repository.ensureProfile()
                _uiState.value = _uiState.value.copy(
                    selectedSkin = skin,
                    unlockedSkins = GameRepository.parseUnlockedSkins(profile.unlockedSkinIdsJson)
                )
            } else {
                audioSynthesizer.playWrong()
            }
        }
    }

    fun equipSkin(skin: SkinItem) {
        viewModelScope.launch {
            repository.updateSkin(skin.id)
            audioSynthesizer.playCoin()
            _uiState.value = _uiState.value.copy(selectedSkin = skin)
        }
    }

    fun upgradePowerUp(powerUpId: String, cost: Int) {
        viewModelScope.launch {
            val success = repository.upgradePowerUp(powerUpId, cost)
            if (success) {
                audioSynthesizer.playLevelUp()
                vibrate(30)
            } else {
                audioSynthesizer.playWrong()
            }
        }
    }

    fun updateSettings(
        sound: Boolean,
        music: Boolean,
        haptics: Boolean,
        sensitivity: Float,
        graphics: String
    ) {
        viewModelScope.launch {
            repository.updateSettings(sound, music, haptics, sensitivity, graphics)
            audioSynthesizer.isSoundEnabled = sound
            audioSynthesizer.isMusicEnabled = music
            if (music) audioSynthesizer.startBackgroundMusic() else audioSynthesizer.stopBackgroundMusic()
        }
    }

    private fun vibrate(ms: Long) {
        val profile = playerProfile.value ?: return
        if (!profile.hapticsEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(ms)
            }
        } catch (_: Exception) {}
    }
}
